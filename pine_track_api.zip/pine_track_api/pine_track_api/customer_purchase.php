<?php
header('Content-Type: application/json');
include 'config.php';

// This API will be called when a customer makes a purchase
$product_id = $_POST['product_id'] ?? '';
$seller_id = $_POST['seller_id'] ?? '';
$customer_id = $_POST['customer_id'] ?? NULL;
$quantity = $_POST['quantity'] ?? '';
$payment_method = $_POST['payment_method'] ?? 'cash';
$notes = $_POST['notes'] ?? '';

if(empty($product_id) || empty($seller_id) || empty($quantity)){
    echo json_encode(['status'=>'error', 'message'=>'Required fields missing']);
    exit;
}

// Get product price
$stmt = $conn->prepare("SELECT price, stock_quantity FROM products WHERE id = ? AND seller_id = ?");
$stmt->bind_param("ii", $product_id, $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if(!$product){
    echo json_encode(['status'=>'error', 'message'=>'Product not found']);
    exit;
}

// Check stock
if($product['stock_quantity'] < $quantity){
    echo json_encode(['status'=>'error', 'message'=>'Insufficient stock']);
    exit;
}

$unit_price = $product['price'];
$total_price = $unit_price * $quantity;

// Start transaction
$conn->begin_transaction();

try {
    // Insert sale record
    $stmt = $conn->prepare("INSERT INTO sales_transactions (
        product_id, 
        seller_id, 
        customer_id, 
        quantity, 
        unit_price, 
        total_price, 
        payment_method,
        notes,
        status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'completed')");
    
    $stmt->bind_param(
        "iiiiddss", 
        $product_id, 
        $seller_id, 
        $customer_id, 
        $quantity, 
        $unit_price, 
        $total_price, 
        $payment_method,
        $notes
    );
    
    if(!$stmt->execute()){
        throw new Exception("Failed to record sale");
    }
    
    // Update product stock
    $updateStmt = $conn->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");
    $updateStmt->bind_param("ii", $quantity, $product_id);
    
    if(!$updateStmt->execute()){
        throw new Exception("Failed to update stock");
    }
    
    $conn->commit();
    
    // Get the sale ID
    $sale_id = $conn->insert_id;
    
    echo json_encode([
        'status'=>'success', 
        'message'=>'Purchase completed successfully',
        'sale_id' => $sale_id,
        'total_price' => $total_price
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['status'=>'error', 'message'=>$e->getMessage()]);
}

$stmt->close();
if(isset($updateStmt)) $updateStmt->close();
$conn->close();
?>