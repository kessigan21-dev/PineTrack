<?php
$path = __DIR__ . "/test_output.txt";
file_put_contents($path, "Test OK\n", FILE_APPEND);
echo "Done";
?>
