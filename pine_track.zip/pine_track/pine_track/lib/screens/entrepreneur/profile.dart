import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'profile_edit.dart';

class SellerProfile extends StatefulWidget {
  final String id;
  const SellerProfile({Key? key, required this.id}) : super(key: key);

  @override
  State<SellerProfile> createState() => _SellerProfileState();
}

class _SellerProfileState extends State<SellerProfile> {
  Map<String, dynamic> profile = {};
  bool isLoading = true;

  final String apiUrl = "http://192.168.56.1/pine_track_api/get_profile.php";

  @override
  void initState() {
    super.initState();
    fetchProfile();
  }

  void fetchProfile() async {
    try {
      var response = await http.get(Uri.parse("$apiUrl?id=${widget.id}"));
      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          profile = data['profile'];
          isLoading = false;
        });
      } else {
        Fluttertoast.showToast(msg: data['message']);
        setState(() => isLoading = false);
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
      setState(() => isLoading = false);
    }
  }

  // ------------------ SOCIAL LINKS PARSING ------------------
  List<Map<String, dynamic>> _parseSocialLinks(String? socialText) {
    if (socialText == null || socialText.isEmpty) return [];

    final links = <Map<String, dynamic>>[];
    final lines = socialText.split('\n');

    for (var line in lines) {
      line = line.trim();
      if (line.isEmpty) continue;

      String platform = '';
      String url = '';
      String displayText = line;

      // Detect platform and build proper URL
      if (line.toLowerCase().contains('facebook') || line.contains('fb.com')) {
        platform = 'Facebook';
        url = _buildFacebookUrl(line);
      } else if (line.toLowerCase().contains('instagram') || line.contains('@') || line.contains('instagram.com')) {
        platform = 'Instagram';
        url = _buildInstagramUrl(line);
      } else if (line.toLowerCase().contains('twitter') || line.contains('twitter.com')) {
        platform = 'Twitter';
        url = _buildTwitterUrl(line);
      } else if (line.toLowerCase().contains('whatsapp')) {
        platform = 'WhatsApp';
        url = _buildWhatsappUrl(line);
      } else if (line.toLowerCase().contains('tiktok') || line.contains('tiktok.com')) {
        platform = 'TikTok';
        url = _buildTikTokUrl(line);
      } else if (line.contains('http') || line.contains('www.')) {
        platform = 'Website';
        url = _ensureHttp(line);
      } else {
        platform = 'Social';
        url = _buildSearchUrl(line);
      }

      links.add({
        'platform': platform,
        'url': url,
        'displayText': displayText,
      });
    }

    return links;
  }

  // ------------------ URL BUILDERS ------------------
  String _ensureHttp(String text) {
    if (!text.startsWith('http')) return 'https://$text';
    return text;
  }

  String _buildFacebookUrl(String input) {
    input = input.replaceAll(RegExp(r'facebook\.com|fb\.com'), '').replaceAll('/', '').trim();
    return 'https://www.facebook.com/$input';
  }

  String _buildInstagramUrl(String input) {
    input = input.replaceAll(RegExp(r'instagram\.com|@'), '').replaceAll('/', '').trim();
    return 'https://www.instagram.com/$input';
  }

  String _buildTwitterUrl(String input) {
    input = input.replaceAll(RegExp(r'twitter\.com|@'), '').replaceAll('/', '').trim();
    return 'https://twitter.com/$input';
  }

  String _buildTikTokUrl(String input) {
    input = input.replaceAll(RegExp(r'tiktok\.com|@'), '').replaceAll('/', '').trim();
    return 'https://www.tiktok.com/@$input';
  }

  String _buildWhatsappUrl(String input) {
    final numberMatch = RegExp(r'\+?\d+').firstMatch(input);
    if (numberMatch != null) return 'https://wa.me/${numberMatch.group(0)}';
    return 'https://wa.me/';
  }

  String _buildSearchUrl(String input) {
    return 'https://www.google.com/search?q=${Uri.encodeComponent(input)}';
  }

  // ------------------ URL LAUNCH ------------------
  Future<void> _launchUrl(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) {
      Fluttertoast.showToast(msg: "Invalid URL");
      return;
    }

    try {
      await launchUrl(
        uri,
        mode: LaunchMode.externalApplication, // Force browser
      );
    } catch (e) {
      Fluttertoast.showToast(msg: "Cannot open link");
    }
  }

  // ------------------ UI HELPERS ------------------
  IconData _getSocialIcon(String platform) {
    switch (platform.toLowerCase()) {
      case 'facebook':
        return Icons.facebook;
      case 'instagram':
        return Icons.camera_alt;
      case 'twitter':
        return Icons.auto_awesome;
      case 'whatsapp':
        return Icons.chat;
      case 'tiktok':
        return Icons.music_note;
      case 'website':
        return Icons.public;
      default:
        return Icons.link;
    }
  }

  Color _getSocialColor(String platform) {
    switch (platform.toLowerCase()) {
      case 'facebook':
        return const Color(0xFF1877F2);
      case 'instagram':
        return const Color(0xFFE4405F);
      case 'twitter':
        return const Color(0xFF1DA1F2);
      case 'whatsapp':
        return const Color(0xFF25D366);
      case 'tiktok':
        return Colors.black;
      default:
        return Colors.green.shade700;
    }
  }

  Widget _buildInfoCard(String title, String value, IconData icon) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: Icon(icon, color: Colors.green.shade700),
        title: Text(title, style: const TextStyle(fontSize: 14, color: Colors.grey)),
        subtitle: Text(value.isEmpty ? 'Not set' : value,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
      ),
    );
  }

  Widget _buildSocialCard(Map<String, dynamic> social) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: _getSocialColor(social['platform']),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(_getSocialIcon(social['platform']), color: Colors.white, size: 20),
        ),
        title: Text(social['platform'], style: const TextStyle(fontWeight: FontWeight.w500)),
        subtitle: Text(social['displayText'], style: TextStyle(color: Colors.blue.shade700, fontSize: 14)),
        trailing: social['url'].isNotEmpty
            ? IconButton(
          icon: const Icon(Icons.open_in_new, size: 20),
          onPressed: () => _launchUrl(social['url']),
        )
            : null,
        onTap: social['url'].isNotEmpty
            ? () => _launchUrl(social['url'])
            : null,
      ),
    );
  }

  // ------------------ BUILD ------------------
  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Colors.green)))
        : RefreshIndicator(
      onRefresh: () async => fetchProfile(),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile Header
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Container(
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        color: Colors.green.shade100,
                        borderRadius: BorderRadius.circular(35),
                      ),
                      child: Icon(Icons.person, size: 40, color: Colors.green.shade700),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(profile['name'] ?? 'No Name',
                              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text(profile['email'] ?? 'No Email',
                              style: TextStyle(fontSize: 14, color: Colors.grey.shade600)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Contact Information', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.green)),
            const SizedBox(height: 12),
            _buildInfoCard('Phone Number', profile['phone'] ?? '', Icons.phone),
            _buildInfoCard('Farm Location', profile['farm_location'] ?? '', Icons.location_on),
            _buildInfoCard('Shop Information', profile['shop_info'] ?? '', Icons.store),
            const SizedBox(height: 24),
            Row(
              children: [
                const Text('Social Media Links', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.green)),
                const SizedBox(width: 8),
                if (profile['social_media']?.isNotEmpty == true)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(12)),
                    child: Text('${_parseSocialLinks(profile['social_media']).length} links',
                        style: TextStyle(fontSize: 12, color: Colors.green.shade700)),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            if (profile['social_media']?.isEmpty ?? true)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(
                    child: Column(
                      children: [Icon(Icons.link_off, size: 40, color: Colors.grey), SizedBox(height: 8), Text('No social links added', style: TextStyle(color: Colors.grey))],
                    ),
                  ),
                ),
              )
            else
              Column(children: _parseSocialLinks(profile['social_media']).map(_buildSocialCard).toList()),
            const SizedBox(height: 30),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => SellerProfileEdit(id: widget.id, initialProfile: profile)),
                      ).then((_) => fetchProfile());
                    },
                    icon: const Icon(Icons.edit, size: 20),
                    label: const Text('Edit Profile'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade700,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => fetchProfile(),
                    icon: const Icon(Icons.refresh, size: 20),
                    label: const Text('Refresh'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      side: BorderSide(color: Colors.green.shade700),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

