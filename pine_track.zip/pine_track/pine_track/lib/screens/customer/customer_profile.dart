import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'customer_profile_edit.dart';

class CustomerProfile extends StatefulWidget {
  final String customerId;
  final String customerName;

  const CustomerProfile({
    Key? key,
    required this.customerId,
    required this.customerName,
  }) : super(key: key);

  @override
  State<CustomerProfile> createState() => _CustomerProfileState();
}

class _CustomerProfileState extends State<CustomerProfile> {
  Map<String, dynamic> profile = {};
  bool isLoading = true;
  int totalPurchases = 0;
  double totalSpent = 0.0;

  final String apiUrl = "http://192.168.56.1/pine_track_api";

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    setState(() => isLoading = true);
    await Future.wait([
      fetchProfile(),
      fetchPurchaseStats(),
    ]);
    setState(() => isLoading = false);
  }

  Future<void> fetchProfile() async {
    try {
      var response = await http.get(
        Uri.parse("$apiUrl/get_customer_profile.php?id=${widget.customerId}"),
      );

      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          profile = data['profile'];
        });
      } else {
        Fluttertoast.showToast(msg: data['message']);
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
    }
  }

  Future<void> fetchPurchaseStats() async {
    try {
      var response = await http.get(
        Uri.parse("$apiUrl/get_customer_purchase_history.php?customer_id=${widget.customerId}"),
      );

      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        List purchases = data['purchases'] ?? [];
        setState(() {
          totalPurchases = purchases.length;
          totalSpent = purchases.fold(0.0, (sum, item) {
            try {
              return sum + double.parse(item['total_price']?.toString() ?? '0');
            } catch (e) {
              return sum;
            }
          });
        });
      }
    } catch (e) {
      print("Error fetching stats: $e");
    }
  }

  Widget _buildInfoCard(String title, String value, IconData icon) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: Icon(icon, color: Colors.green.shade700),
        title: Text(title, style: TextStyle(fontSize: 14, color: Colors.grey)),
        subtitle: Text(value.isEmpty ? 'Not set' : value,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, Color color) {
    return Card(
      elevation: 2,
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [color.withOpacity(0.1), color.withOpacity(0.05)],
          ),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Profile"),
        backgroundColor: Colors.green.shade700,
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CustomerProfileEdit(
                    customerId: widget.customerId,
                    initialProfile: profile,
                  ),
                ),
              ).then((_) {
                fetchData(); // Use fetchData instead of individual methods
              });
            },
          ),
        ],
      ),
      body: isLoading
          ? Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
        ),
      )
          : RefreshIndicator(
        onRefresh: fetchData, // Simplified - just call fetchData
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Profile Header
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Row(
                    children: [
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          color: Colors.green.shade100,
                          borderRadius: BorderRadius.circular(40),
                        ),
                        child: Icon(
                          Icons.person,
                          size: 50,
                          color: Colors.green.shade700,
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              profile['name'] ?? widget.customerName,
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              profile['email'] ?? 'No Email',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              "Member since ${DateTime.tryParse(profile['created_at']?.toString() ?? '')?.year ?? DateTime.now().year}",
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              SizedBox(height: 24),

              // Purchase Stats
              Text(
                'Purchase Statistics',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.green,
                ),
              ),
              SizedBox(height: 12),

              GridView.count(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                childAspectRatio: 1.5,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                children: [
                  _buildStatCard(
                    'Total Purchases',
                    totalPurchases.toString(),
                    Colors.green.shade700,
                  ),
                  _buildStatCard(
                    'Total Spent',
                    'RM ${totalSpent.toStringAsFixed(2)}',
                    Colors.blue.shade700,
                  ),
                ],
              ),

              SizedBox(height: 24),

              // Contact Information
              Text(
                'Contact Information',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.green,
                ),
              ),
              SizedBox(height: 12),

              _buildInfoCard('Email Address', profile['email']?.toString() ?? '', Icons.email),
              _buildInfoCard('Phone Number', profile['phone']?.toString() ?? '', Icons.phone),
              _buildInfoCard('Address', profile['address']?.toString() ?? '', Icons.location_on),

              SizedBox(height: 24),

              // Account Info
              Text(
                'Account Information',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.green,
                ),
              ),
              SizedBox(height: 12),

              Card(
                elevation: 2,
                margin: EdgeInsets.symmetric(vertical: 6),
                child: ListTile(
                  leading: Icon(Icons.person_pin, color: Colors.green.shade700),
                  title: Text('Customer ID', style: TextStyle(fontSize: 14, color: Colors.grey)),
                  subtitle: Text(widget.customerId, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                ),
              ),

              _buildInfoCard(
                'Member Since',
                profile['created_at'] != null
                    ? DateTime.tryParse(profile['created_at'].toString())?.toLocal().toString().split(' ')[0] ?? 'Unknown'
                    : 'Not available',
                Icons.calendar_today,
              ),

              SizedBox(height: 30),

              // Action Button
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CustomerProfileEdit(
                        customerId: widget.customerId,
                        initialProfile: profile,
                      ),
                    ),
                  ).then((_) {
                    fetchData(); // Use fetchData instead of individual methods
                  });
                },
                icon: Icon(Icons.edit, size: 20),
                label: Text('Edit Profile'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade700,
                  minimumSize: Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),

              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}