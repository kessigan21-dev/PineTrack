<?php
header('Content-Type: application/json');
include 'config.php';

$announcement_id = $_POST['announcement_id'] ?? '';
$seller_id = $_POST['seller_id'] ?? '';

if(empty($announcement_id) || empty($seller_id)){
    echo json_encode(['status'=>'error', 'message'=>'Invalid request']);
    exit;
}

$stmt = $conn->prepare("DELETE FROM announcements WHERE id=? AND seller_id=?");
$stmt->bind_param("ii", $announcement_id, $seller_id);

if($stmt->execute()){
    echo json_encode(['status'=>'success', 'message'=>'Announcement deleted']);
} else {
    echo json_encode(['status'=>'error', 'message'=>'Failed to delete announcement']);
}

$stmt->close();
$conn->close();
?>