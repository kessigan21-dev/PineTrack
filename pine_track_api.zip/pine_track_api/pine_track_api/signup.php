<?php
header('Content-Type: application/json');
include 'config.php';

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$role = $_POST['role'] ?? '';

if(empty($name) || empty($email) || empty($password) || empty($role)){
    echo json_encode(['success'=>false, 'message'=>'Fill all fields']);
    exit;
}

$table = $role === 'Entrepreneur' ? 'entrepreneurs' : 'customers';
$password_hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO $table (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $password_hash);

if($stmt->execute()){
    echo json_encode(['success'=>true, 'message'=>'Account created']);
} else {
    echo json_encode(['success'=>false, 'message'=>'Error: '.$stmt->error]);
}
$stmt->close();
$conn->close();
?>

