import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class AddAnnouncementScreen extends StatefulWidget {
  final String sellerId;
  const AddAnnouncementScreen({Key? key, required this.sellerId}) : super(key: key);

  @override
  State<AddAnnouncementScreen> createState() => _AddAnnouncementScreenState();
}

class _AddAnnouncementScreenState extends State<AddAnnouncementScreen> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController detailsController = TextEditingController();
  final String addAnnouncementUrl = "http://192.168.56.1/pine_track_api/add_announcement.php";

  String selectedType = 'General';
  DateTime? selectedExpiryDate;
  bool isLoading = false;

  final List<String> announcementTypes = [
    'General',
    'Promotion',
    'Event',
    'Maintenance',
    'Important',
  ];

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 7)),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.green,
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        selectedExpiryDate = picked;
      });
    }
  }

  void addAnnouncement() async {
    String title = titleController.text.trim();
    String details = detailsController.text.trim();

    if (title.isEmpty || details.isEmpty) {
      Fluttertoast.showToast(msg: "Title and details are required");
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      var response = await http.post(
        Uri.parse(addAnnouncementUrl),
        body: {
          'seller_id': widget.sellerId,
          'title': titleController.text,
          'type': selectedType,
          'details': detailsController.text,
          'expiry_date': selectedExpiryDate != null
              ? DateFormat('yyyy-MM-dd').format(selectedExpiryDate!)
              : '',
        },
      );

      var data = json.decode(response.body);
      Fluttertoast.showToast(msg: data['message']);

      if (data['status'] == 'success') {
        Navigator.pop(context);
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Color _getTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'promotion':
        return const Color(0xFF4CAF50);
      case 'event':
        return const Color(0xFF2196F3);
      case 'maintenance':
        return const Color(0xFFFF9800);
      case 'important':
        return const Color(0xFFF44336);
      default:
        return const Color(0xFF9C27B0);
    }
  }

  IconData _getTypeIcon(String type) {
    switch (type.toLowerCase()) {
      case 'promotion':
        return Icons.local_offer;
      case 'event':
        return Icons.event;
      case 'maintenance':
        return Icons.build;
      case 'important':
        return Icons.warning;
      default:
        return Icons.announcement;
    }
  }

  Widget _buildTypeChip(String type) {
    final isSelected = selectedType == type;
    return GestureDetector(
      onTap: () => setState(() => selectedType = type),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected
              ? _getTypeColor(type).withOpacity(0.2)
              : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? _getTypeColor(type)
                : Colors.transparent,
            width: 2,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              _getTypeIcon(type),
              size: 18,
              color: isSelected
                  ? _getTypeColor(type)
                  : Colors.grey.shade600,
            ),
            const SizedBox(width: 8),
            Text(
              type,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: isSelected
                    ? _getTypeColor(type)
                    : Colors.grey.shade700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Create Announcement"),
        backgroundColor: Colors.green.shade700,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Announcement Type
            const Text(
              "Announcement Type",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: announcementTypes.map(_buildTypeChip).toList(),
            ),
            const SizedBox(height: 24),

            // Title
            const Text(
              "Title *",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: titleController,
              maxLines: 1,
              decoration: InputDecoration(
                hintText: "Enter announcement title",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              ),
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),

            // Details
            const Text(
              "Details *",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: detailsController,
              maxLines: 6,
              decoration: InputDecoration(
                hintText: "Enter announcement details...",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.all(16),
                alignLabelWithHint: true,
              ),
              style: const TextStyle(fontSize: 14, height: 1.5),
            ),
            const SizedBox(height: 20),

            // Expiry Date (Optional)
            const Text(
              "Expiry Date (Optional)",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () => _selectDate(context),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.calendar_today,
                      color: Colors.grey.shade600,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        selectedExpiryDate != null
                            ? DateFormat('MMM dd, yyyy').format(selectedExpiryDate!)
                            : "Select expiry date (optional)",
                        style: TextStyle(
                          color: selectedExpiryDate != null
                              ? Colors.black
                              : Colors.grey.shade600,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    if (selectedExpiryDate != null)
                      IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          setState(() {
                            selectedExpiryDate = null;
                          });
                        },
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 30),

            // Submit Button
            isLoading
                ? const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
              ),
            )
                : SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: addAnnouncement,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade700,
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 2,
                ),
                child: const Text(
                  "Publish Announcement",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}