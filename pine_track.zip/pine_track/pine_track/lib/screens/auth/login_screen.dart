import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../entrepreneur/dashboard.dart';
import '../customer/dashboard.dart';
import 'signup_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  String selectedRole = "Entrepreneur";
  bool isLoading = false;
  bool _obscurePassword = true;

  final String loginUrl = "http://192.168.56.1/pine_track_api/login.php";

  void showToast(String msg) {
    Fluttertoast.showToast(
      msg: msg,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.black.withOpacity(0.7),
      textColor: Colors.white,
      fontSize: 14,
    );
  }

  void loginUser() async {
    String email = emailController.text.trim();
    String password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      showToast("Please fill all fields");
      return;
    }

    setState(() => isLoading = true);

    try {
      var response = await http.post(
        Uri.parse(loginUrl),
        body: {'email': email, 'password': password, 'role': selectedRole},
      ).timeout(const Duration(seconds: 10));

      print("Raw login response: ${response.body}");

      var data = json.decode(response.body);

      bool isSuccess = false;
      dynamic userData;
      String message = "";

      if (data.containsKey('status')) {
        isSuccess = data['status'] == 'success';
        userData = data['user'] ?? data;
        message = data['message'] ?? "";
      } else if (data.containsKey('success')) {
        isSuccess = data['success'] == true;
        userData = data['user'] ?? data;
        message = data['message'] ?? "";
      }

      if (isSuccess) {
        String userName = "";
        String userId = "";

        if (userData is Map<String, dynamic>) {
          userName = userData['name'] ?? "User";
          userId = userData['id']?.toString() ?? "";
        } else {
          userName = "User";
          userId = "";
        }

        showToast("Welcome $userName");

        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('customer_id', userId);
        await prefs.setString('customer_name', userName);
        await prefs.setString('customer_email', userData['email']?.toString() ?? "");

        if (selectedRole == "Entrepreneur") {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SellerDashboard(sellerId: userId.isNotEmpty ? userId : "1"),
            ),
          );
        } else {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => CustomerDashboard(),
            ),
          );
        }
      } else {
        showToast(message.isNotEmpty ? message : "Invalid login");
      }
    } catch (e) {
      showToast("Login error: Check your connection");
      print("Login error: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/background.png'),
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(
                    Colors.black.withOpacity(0.15),
                    BlendMode.darken,
                  ),
                ),
              ),
            ),
          ),

          SingleChildScrollView(
            child: Container(
              height: MediaQuery.of(context).size.height,
              child: Center(
                child: Container(
                  width: double.infinity,
                  constraints: BoxConstraints(maxWidth: 450),
                  margin: EdgeInsets.all(20),
                  child: Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(40.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          // ----------------------------------------------------------
                          //   UPDATED: WELCOME + LOGO ROW (top)
                          // ----------------------------------------------------------
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Welcome',
                                      style: TextStyle(
                                        fontSize: 28,
                                        color: Colors.grey[700],
                                        fontWeight: FontWeight.w300,
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    Text(
                                      'Back',
                                      style: TextStyle(
                                        fontSize: 36,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF2E7D32),
                                      ),
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      'Pineapple Tracking System',
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey[600],
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              // Logo on the top-right
                              SizedBox(
                                width: 140,
                                height: 140,
                                child: Image.asset(
                                  'lib/assets/images/pinetrack_solo.png',
                                  fit: BoxFit.contain,
                                ),
                              ),
                            ],
                          ),
                          // ----------------------------------------------------------

                          SizedBox(height: 40),

                          // Email
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Email',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[700],
                                ),
                              ),
                              SizedBox(height: 8),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: Colors.grey[300]!,
                                    width: 1.5,
                                  ),
                                ),
                                child: TextField(
                                  controller: emailController,
                                  style: TextStyle(fontSize: 16, color: Colors.grey[800]),
                                  decoration: InputDecoration(
                                    hintText: "giga@example.com",
                                    hintStyle: TextStyle(color: Colors.grey[500]),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.symmetric(
                                      horizontal: 16,
                                      vertical: 16,
                                    ),
                                    prefixIcon: Icon(Icons.email_outlined, color: Colors.grey[600]),
                                  ),
                                  keyboardType: TextInputType.emailAddress,
                                ),
                              ),
                            ],
                          ),

                          SizedBox(height: 24),

                          // Password
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Password',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[700],
                                ),
                              ),
                              SizedBox(height: 8),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: Colors.grey[300]!,
                                    width: 1.5,
                                  ),
                                ),
                                child: TextField(
                                  controller: passwordController,
                                  style: TextStyle(fontSize: 16, color: Colors.grey[800]),
                                  decoration: InputDecoration(
                                    hintText: "• • • • • • • •",
                                    hintStyle: TextStyle(
                                      color: Colors.grey[500],
                                      letterSpacing: 2,
                                    ),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.symmetric(
                                      horizontal: 16,
                                      vertical: 16,
                                    ),
                                    prefixIcon: Icon(Icons.lock_outline, color: Colors.grey[600]),
                                    suffixIcon: IconButton(
                                      icon: Icon(
                                        _obscurePassword
                                            ? Icons.visibility_outlined
                                            : Icons.visibility_off_outlined,
                                        color: Colors.grey[600],
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          _obscurePassword = !_obscurePassword;
                                        });
                                      },
                                    ),
                                  ),
                                  obscureText: _obscurePassword,
                                ),
                              ),
                            ],
                          ),

                          SizedBox(height: 16),

                          // Role Selector
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Login as',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[700],
                                ),
                              ),
                              SizedBox(height: 8),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: Colors.grey[300]!,
                                    width: 1.5,
                                  ),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    value: selectedRole,
                                    isExpanded: true,
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.grey[800],
                                    ),
                                    items: ["Entrepreneur", "Customer"]
                                        .map((role) => DropdownMenuItem(
                                      value: role,
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 16),
                                        child: Text(role),
                                      ),
                                    ))
                                        .toList(),
                                    onChanged: (v) {
                                      setState(() {
                                        selectedRole = v!;
                                      });
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),

                          SizedBox(height: 32),

                          // Sign In
                          SizedBox(
                            width: double.infinity,
                            height: 56,
                            child: ElevatedButton(
                              onPressed: isLoading ? null : loginUser,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xFF2E7D32),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 0,
                                shadowColor: Colors.transparent,
                              ),
                              child: isLoading
                                  ? SizedBox(
                                height: 22,
                                width: 22,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                                  : Text(
                                "Sign in",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),

                          SizedBox(height: 24),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TextButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (_) => SignupScreen()),
                                  );
                                },
                                child: Text(
                                  "Sign up",
                                  style: TextStyle(
                                    fontSize: 15,
                                    color: Color(0xFF2E7D32),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              TextButton(
                                onPressed: () {
                                  showToast("Forgot password feature coming soon!");
                                },
                                child: Text(
                                  "Forgot Password?",
                                  style: TextStyle(
                                    fontSize: 15,
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),

                          SizedBox(height: 20),

                          Row(
                            children: [
                              Expanded(child: Divider(color: Colors.grey[300], thickness: 1)),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16),
                                child: Text(
                                  "PineTrack",
                                  style: TextStyle(
                                    color: Colors.grey[500],
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                              Expanded(child: Divider(color: Colors.grey[300], thickness: 1)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
