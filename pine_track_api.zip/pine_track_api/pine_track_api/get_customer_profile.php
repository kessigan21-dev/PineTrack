<?php
header('Content-Type: application/json');
include 'config.php';

$id = (int)($_GET['id'] ?? 0);

if($id === 0){
    echo json_encode(['status'=>'error', 'message'=>'Customer ID required']);
    exit;
}

$stmt = $conn->prepare("
    SELECT id, name, email, phone, address, profile_picture, created_at 
    FROM customers 
    WHERE id=?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if($row = $result->fetch_assoc()){
    echo json_encode(['status'=>'success','profile'=>$row]);
}else{
    echo json_encode(['status'=>'error','message'=>'Customer profile not found']);
}

$stmt->close();
$conn->close();
?>