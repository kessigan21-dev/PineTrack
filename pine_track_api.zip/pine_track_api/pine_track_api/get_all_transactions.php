<?php
// get_all_transactions.php
header('Content-Type: application/json');
include 'config.php';

$seller_id = $_GET['seller_id'] ?? '';

if(empty($seller_id)){
    echo json_encode(['status'=>'error', 'message'=>'Seller ID required']);
    exit;
}

$stmt = $conn->prepare("
    SELECT 
        st.*,
        p.name as product_name,
        c.name as customer_name,
        DATE_FORMAT(st.transaction_date, '%Y-%m-%d %H:%i') as date
    FROM sales_transactions st
    JOIN products p ON st.product_id = p.id
    LEFT JOIN customers c ON st.customer_id = c.id
    WHERE st.seller_id = ? 
    ORDER BY st.transaction_date DESC
");

$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();

$transactions = [];
while($row = $result->fetch_assoc()){
    $transactions[] = $row;
}

echo json_encode([
    'status' => 'success',
    'transactions' => $transactions
]);

$stmt->close();
$conn->close();
?>