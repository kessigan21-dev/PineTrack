import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class CustomerPurchaseHistory extends StatefulWidget {
  final String customerId;

  const CustomerPurchaseHistory({Key? key, required this.customerId}) : super(key: key);

  @override
  State<CustomerPurchaseHistory> createState() => _CustomerPurchaseHistoryState();
}

class _CustomerPurchaseHistoryState extends State<CustomerPurchaseHistory> {
  List<dynamic> purchases = [];
  bool isLoading = true;
  double totalSpent = 0.0;

  final String apiUrl = "http://192.168.56.1/pine_track_api";

  @override
  void initState() {
    super.initState();
    fetchPurchaseHistory();
  }

  Future<void> fetchPurchaseHistory() async {
    try {
      var response = await http.get(
        Uri.parse("$apiUrl/get_customer_purchase_history.php?customer_id=${widget.customerId}"),
      );

      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          purchases = data['purchases'];
          totalSpent = purchases.fold(0.0, (sum, item) => sum + double.parse(item['total_price'].toString()));
        });
      }
    } catch (e) {
      print("Error: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  Widget _buildPurchaseCard(Map<String, dynamic> purchase) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    purchase['product_name'] ?? 'Product',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getStatusColor(purchase['status']).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    purchase['status']?.toUpperCase() ?? '',
                    style: TextStyle(
                      fontSize: 12,
                      color: _getStatusColor(purchase['status']),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        purchase['seller_name'] ?? 'Seller',
                        style: TextStyle(color: Colors.grey.shade600),
                      ),
                      SizedBox(height: 4),
                      Text(
                        purchase['category'] ?? 'Category',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.green.shade700,
                          backgroundColor: Colors.green.shade50,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      "RM ${double.parse(purchase['total_price'].toString()).toStringAsFixed(2)}",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.green.shade800,
                      ),
                    ),
                    Text(
                      "${purchase['quantity']} × RM ${double.parse(purchase['unit_price'].toString()).toStringAsFixed(2)}",
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 12),
            Divider(height: 1),
            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.calendar_today, size: 14, color: Colors.grey.shade500),
                    SizedBox(width: 4),
                    Text(
                      DateFormat('dd MMM yyyy').format(DateTime.parse(purchase['purchase_date'])),
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.payment, size: 14, color: Colors.grey.shade500),
                    SizedBox(width: 4),
                    Text(
                      purchase['payment_method']?.toUpperCase() ?? 'CASH',
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ],
            ),
            if (purchase['notes'] != null && purchase['notes'].isNotEmpty)
              Container(
                margin: EdgeInsets.only(top: 12),
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.note, size: 16, color: Colors.blue.shade700),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        purchase['notes'],
                        style: TextStyle(fontSize: 12, color: Colors.blue.shade800),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String? status) {
    switch (status?.toLowerCase()) {
      case 'completed':
        return Colors.green.shade700;
      case 'pending':
        return Colors.orange.shade700;
      case 'cancelled':
        return Colors.red.shade700;
      default:
        return Colors.grey.shade700;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Purchase History"),
        backgroundColor: Colors.green.shade700,
      ),
      body: RefreshIndicator(
        onRefresh: fetchPurchaseHistory,
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : ListView(
          padding: EdgeInsets.all(16),
          children: [
            // Stats Card
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  children: [
                    Text(
                      "Total Spent",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "RM ${totalSpent.toStringAsFixed(2)}",
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: Colors.green.shade800,
                      ),
                    ),
                    SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            Text(
                              purchases.length.toString(),
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue.shade700,
                              ),
                            ),
                            Text(
                              "Purchases",
                              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                        Container(
                          width: 1,
                          height: 30,
                          color: Colors.grey.shade300,
                        ),
                        Column(
                          children: [
                            Text(
                              purchases.where((p) => p['status'] == 'completed').length.toString(),
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.green.shade700,
                              ),
                            ),
                            Text(
                              "Completed",
                              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 24),
            Text(
              "Recent Purchases",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Colors.green.shade800,
              ),
            ),
            SizedBox(height: 16),
            ...purchases.map((purchase) => _buildPurchaseCard(purchase)).toList(),
            if (purchases.isEmpty)
              Container(
                padding: EdgeInsets.all(40),
                child: Column(
                  children: [
                    Icon(Icons.shopping_cart_outlined, size: 60, color: Colors.grey.shade300),
                    SizedBox(height: 16),
                    Text(
                      "No purchase history yet",
                      style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Start shopping to see your purchases here",
                      style: TextStyle(fontSize: 14, color: Colors.grey.shade500),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}