import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CustomerProfileEdit extends StatefulWidget {
  final String customerId;
  final Map<String, dynamic> initialProfile;

  const CustomerProfileEdit({
    Key? key,
    required this.customerId,
    required this.initialProfile,
  }) : super(key: key);

  @override
  State<CustomerProfileEdit> createState() => _CustomerProfileEditState();
}

class _CustomerProfileEditState extends State<CustomerProfileEdit> {
  late TextEditingController nameController;
  late TextEditingController emailController;
  late TextEditingController phoneController;
  late TextEditingController addressController;

  final String apiUrl = "http://192.168.56.1/pine_track_api/update_customer_profile.php";
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.initialProfile['name'] ?? "");
    emailController = TextEditingController(text: widget.initialProfile['email'] ?? "");
    phoneController = TextEditingController(text: widget.initialProfile['phone'] ?? "");
    addressController = TextEditingController(text: widget.initialProfile['address'] ?? "");
  }

  void updateProfile() async {
    if (nameController.text.isEmpty || emailController.text.isEmpty) {
      Fluttertoast.showToast(msg: "Name and Email are required");
      return;
    }

    setState(() => isLoading = true);

    try {
      var response = await http.post(
        Uri.parse(apiUrl),
        body: {
          "id": widget.customerId,
          "name": nameController.text.trim(),
          "email": emailController.text.trim(),
          "phone": phoneController.text.trim(),
          "address": addressController.text.trim(),
        },
      );

      var data = json.decode(response.body);
      Fluttertoast.showToast(msg: data['message']);

      if (data['status'] == 'success') {
        Navigator.pop(context);
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    addressController.dispose();
    super.dispose();
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    int? maxLines,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: Colors.grey.shade50,
        prefixIcon: Icon(icon, color: Colors.green.shade700),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Profile"),
        backgroundColor: Colors.green.shade700,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            // Profile Picture
            Center(
              child: Stack(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.green.shade100,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.green.shade300, width: 2),
                    ),
                    child: Icon(
                      Icons.person,
                      size: 50,
                      color: Colors.green.shade700,
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.green.shade700,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.camera_alt, size: 20, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30),

            // Form Fields
            _buildTextField(
              controller: nameController,
              label: "Full Name*",
              icon: Icons.person,
            ),
            SizedBox(height: 16),

            _buildTextField(
              controller: emailController,
              label: "Email Address*",
              icon: Icons.email,
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 16),

            _buildTextField(
              controller: phoneController,
              label: "Phone Number",
              icon: Icons.phone,
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: 16),

            _buildTextField(
              controller: addressController,
              label: "Address",
              icon: Icons.location_on,
              maxLines: 3,
            ),
            SizedBox(height: 30),

            // Action Buttons
            isLoading
                ? Center(child: CircularProgressIndicator())
                : Column(
              children: [
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: updateProfile,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade700,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text(
                      "Save Changes",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    style: OutlinedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text("Cancel"),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}