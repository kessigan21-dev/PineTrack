<?php
header('Content-Type: application/json');
include 'config.php';

// Use 'id' from GET
$id = (int)($_GET['id'] ?? 0);

if($id === 0){
    echo json_encode(['status'=>'error', 'message'=>'ID required']);
    exit;
}

$stmt = $conn->prepare("
    SELECT id, name, email, phone, farm_location, shop_info, social_media 
    FROM entrepreneurs 
    WHERE id=?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if($row = $result->fetch_assoc()){
    echo json_encode(['status'=>'success','profile'=>$row]);
}else{
    echo json_encode(['status'=>'error','message'=>'Profile not found']);
}

$stmt->close();
$conn->close();
?>
