import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'customer_profile.dart';
import 'customer_purchase.dart';
import 'customer_purchase_history.dart';
import '../auth/login_screen.dart';
import 'package:pine_track/constants/theme.dart'; // Import your theme
import 'package:google_fonts/google_fonts.dart'; // Add this import

class CustomerDashboard extends StatefulWidget {
  const CustomerDashboard({Key? key}) : super(key: key);

  @override
  State<CustomerDashboard> createState() => _CustomerDashboardState();
}

class _CustomerDashboardState extends State<CustomerDashboard> {
  int _selectedIndex = 0;
  List<dynamic> products = [];
  List<dynamic> announcements = [];
  List<dynamic> purchaseHistory = [];
  bool isLoading = true;
  double totalSpent = 0.0;
  int totalPurchases = 0;

  // User data that will be fetched
  String customerId = "";
  String customerName = "Customer";
  String customerEmail = "";

  bool isLoggedIn = false;

  final String baseUrl = "http://192.168.56.1/pine_track_api";

  @override
  void initState() {
    super.initState();
    _initializeUserData();
  }

  Future<void> _initializeUserData() async {
    // Try to get user data from SharedPreferences
    final prefs = await SharedPreferences.getInstance();

    setState(() {
      customerId = prefs.getString('customer_id') ?? "";
      customerName = prefs.getString('customer_name') ?? "Customer";
      customerEmail = prefs.getString('customer_email') ?? "";
      isLoggedIn = customerId.isNotEmpty;
    });

    if (isLoggedIn) {
      await _loadAllData();
    } else {
      setState(() => isLoading = false);
    }
  }

  Future<void> _loadAllData() async {
    setState(() => isLoading = true);
    await Future.wait([
      _fetchProducts(),
      _fetchAnnouncements(),
      _fetchPurchaseHistory(),
    ]);
    setState(() => isLoading = false);
  }

  Future<void> _fetchProducts() async {
    try {
      var response = await http.get(
        Uri.parse("$baseUrl/get_products.php"),
      );
      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() => products = data['products']);
      } else {
        print("Error fetching products: ${data['message']}");
      }
    } catch (e) {
      print("Error fetching products: $e");
    }
  }

  Future<void> _fetchAnnouncements() async {
    try {
      var response = await http.get(
        Uri.parse("$baseUrl/get_announcements.php"),
      );
      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() => announcements = data['announcements']);
      } else {
        print("Error fetching announcements: ${data['message']}");
      }
    } catch (e) {
      print("Error fetching announcements: $e");
    }
  }

  Future<void> _fetchPurchaseHistory() async {
    if (customerId.isEmpty) return;

    try {
      var response = await http.get(
        Uri.parse("$baseUrl/get_customer_purchase_history.php?customer_id=$customerId"),
      );
      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        List purchases = data['purchases'] ?? [];
        setState(() {
          purchaseHistory = purchases;
          totalPurchases = purchases.length;
          totalSpent = purchases.fold(0.0, (sum, item) {
            double price = double.tryParse(item['total_price']?.toString() ?? '0') ?? 0;
            return sum + price;
          });
        });
      }
    } catch (e) {
      print("Error fetching purchase history: $e");
    }
  }

  // UPDATED LOGOUT FUNCTION
  Future<void> _logoutUser() async {
    bool confirmLogout = await showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.dangerColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.logout_rounded,
                      color: AppTheme.dangerColor,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      "Confirm Logout",
                      style: GoogleFonts.montserrat(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                "Are you sure you want to logout from your account?",
                style: GoogleFonts.inter(
                  fontSize: 15,
                  color: AppTheme.textSecondary,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 28),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    ),
                    child: Text(
                      "Cancel",
                      style: GoogleFonts.inter(
                        fontWeight: FontWeight.w500,
                        color: AppTheme.textTertiary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.dangerColor,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      "Logout",
                      style: GoogleFonts.inter(
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ) ?? false;

    if (confirmLogout) {
      // Clear user data from SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('customer_id');
      await prefs.remove('customer_name');
      await prefs.remove('customer_email');

      // Navigate back to login screen
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => LoginScreen()),
            (route) => false,
      );
    }
  }

  Widget _buildStatsCard() {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem(
                  icon: Icons.shopping_cart_rounded,
                  value: totalPurchases.toString(),
                  label: "Purchases",
                  color: AppTheme.primaryGreen,
                ),
                _buildStatItem(
                  icon: Icons.currency_exchange_rounded,
                  value: "RM ${totalSpent.toStringAsFixed(2)}",
                  label: "Total Spent",
                  color: AppTheme.infoColor,
                ),
                _buildStatItem(
                  icon: Icons.store_rounded,
                  value: products.length.toString(),
                  label: "Products",
                  color: AppTheme.warningColor,
                ),
              ],
            ),
            SizedBox(height: 12),
            Text(
              "Welcome, $customerName",
              style: GoogleFonts.inter(
                fontSize: 14,
                color: AppTheme.primaryGreen,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem({required IconData icon, required String value, required String label, required Color color}) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 24),
        ),
        SizedBox(height: 8),
        Text(value, style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: AppTheme.textPrimary,
        )),
        Text(label, style: TextStyle(
          fontSize: 12,
          color: AppTheme.textTertiary,
        )),
      ],
    );
  }

  Widget _buildProductCard(Map<String, dynamic> product) {
    bool isAvailable = (product['is_available'] == 1 || product['is_available'] == true);
    int stock = int.tryParse(product['stock_quantity']?.toString() ?? '0') ?? 0;

    // Clean the product name to remove any special formatting or HTML-like tags
    String cleanProductName = (product['name']?.toString() ?? 'Unnamed Product')
        .replaceAll(RegExp(r'<[^>]*>|\[.*?\]|\n'), '') // Remove HTML tags and brackets
        .trim();

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: EdgeInsets.symmetric(vertical: 8),
      child: InkWell(
        onTap: isAvailable && stock > 0 && isLoggedIn
            ? () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => CustomerPurchaseScreen(
                product: product,
                customerId: customerId,
              ),
            ),
          ).then((_) {
            // Refresh data after purchase
            _fetchProducts();
            _fetchPurchaseHistory();
          });
        }
            : () {
          if (!isLoggedIn) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text("Please log in to purchase"),
                backgroundColor: AppTheme.primaryGreen,
              ),
            );
          }
        },
        borderRadius: BorderRadius.circular(12),
        child: Opacity(
          opacity: isAvailable && stock > 0 ? 1.0 : 0.6,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Product Image
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.grey.shade100,
                    image: product['image_url'] != null &&
                        product['image_url'].toString().isNotEmpty &&
                        product['image_url'].toString().startsWith('http')
                        ? DecorationImage(
                      image: NetworkImage(product['image_url'].toString()),
                      fit: BoxFit.cover,
                    )
                        : null,
                  ),
                  child: product['image_url'] == null ||
                      product['image_url'].toString().isEmpty ||
                      !product['image_url'].toString().startsWith('http')
                      ? Icon(Icons.shopping_bag_rounded, color: Colors.grey.shade400, size: 40)
                      : null,
                ),
                SizedBox(width: 16),

                // Product Details - FIXED: Added constraints to prevent overflow
                Expanded(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minWidth: 0,
                      maxWidth: double.infinity,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Text(
                                cleanProductName, // Use cleaned product name
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: isAvailable && stock > 0 ? AppTheme.textPrimary : AppTheme.textTertiary,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (!isAvailable || stock <= 0)
                              Container(
                                constraints: BoxConstraints(
                                  maxWidth: 80, // Limit width of status badge
                                ),
                                margin: EdgeInsets.only(left: 8),
                                padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppTheme.dangerColor.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(4),
                                  border: Border.all(color: AppTheme.dangerColor.withOpacity(0.3)),
                                ),
                                child: Text(
                                  stock <= 0 ? "Out of Stock" : "Unavailable",
                                  style: TextStyle(fontSize: 10, color: AppTheme.dangerColor),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                ),
                              ),
                          ],
                        ),

                        SizedBox(height: 4),

                        Text(
                          product['seller_name']?.toString() ?? 'Unknown Seller',
                          style: TextStyle(fontSize: 12, color: AppTheme.textTertiary),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),

                        SizedBox(height: 8),

                        // Price row with flexible layout
                        LayoutBuilder(
                          builder: (context, constraints) {
                            return ConstrainedBox(
                              constraints: BoxConstraints(
                                maxWidth: constraints.maxWidth,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Flexible(
                                    child: Text(
                                      "RM ${(double.tryParse(product['price']?.toString() ?? '0') ?? 0).toStringAsFixed(2)}",
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: AppTheme.primaryGreen,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Flexible(
                                    child: Text(
                                      "/ ${product['unit']?.toString() ?? 'unit'}",
                                      style: TextStyle(fontSize: 14, color: AppTheme.textTertiary),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Spacer(),
                                  if (product['promotion'] != null && product['promotion'].toString().isNotEmpty)
                                    Container(
                                      constraints: BoxConstraints(
                                        maxWidth: 80, // Limit width of promotion badge
                                      ),
                                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: AppTheme.warningColor.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(4),
                                        border: Border.all(color: AppTheme.warningColor.withOpacity(0.3)),
                                      ),
                                      child: Text(
                                        product['promotion'].toString(),
                                        style: TextStyle(fontSize: 11, color: AppTheme.warningColor),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),

                        SizedBox(height: 8),

                        if (product['category'] != null)
                          Wrap(
                            spacing: 8,
                            runSpacing: 4,
                            children: [
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppTheme.primaryGreen.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(4),
                                  border: Border.all(color: AppTheme.primaryGreen.withOpacity(0.3)),
                                ),
                                child: Text(
                                  product['category'].toString(),
                                  style: TextStyle(fontSize: 11, color: AppTheme.primaryGreen),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (stock > 0)
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: AppTheme.successColor.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(color: AppTheme.successColor.withOpacity(0.3)),
                                  ),
                                  child: Text(
                                    "Stock: $stock",
                                    style: TextStyle(fontSize: 11, color: AppTheme.successColor),
                                    maxLines: 1,
                                  ),
                                ),
                            ],
                          ),
                      ],
                    ),
                  ),
                ),

                if (isAvailable && stock > 0 && isLoggedIn)
                  Padding(
                    padding: EdgeInsets.only(left: 8),
                    child: Icon(Icons.chevron_right_rounded, color: AppTheme.textTertiary, size: 20),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAnnouncementCard(Map<String, dynamic> announcement) {
    Color typeColor = AppTheme.primaryGreen;
    IconData typeIcon = Icons.announcement_rounded;

    String type = announcement['type']?.toString().toLowerCase() ?? 'general';
    switch (type) {
      case 'promotion':
        typeColor = AppTheme.warningColor;
        typeIcon = Icons.local_offer_rounded;
        break;
      case 'news':
        typeColor = AppTheme.infoColor;
        typeIcon = Icons.newspaper_rounded;
        break;
      case 'event':
        typeColor = Colors.purple.shade700;
        typeIcon = Icons.event_rounded;
        break;
    }

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: typeColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(typeIcon, size: 14, color: typeColor),
                      SizedBox(width: 4),
                      Text(
                        announcement['type']?.toString() ?? 'General',
                        style: TextStyle(fontSize: 12, color: typeColor, fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ),
                Spacer(),
                if (announcement['seller_name'] != null)
                  Text(
                    announcement['seller_name'].toString(),
                    style: TextStyle(fontSize: 12, color: AppTheme.textTertiary),
                  ),
              ],
            ),
            SizedBox(height: 12),
            Text(
              announcement['title']?.toString() ?? '',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimary,
              ),
            ),
            SizedBox(height: 8),
            Text(
              announcement['details']?.toString() ?? '',
              style: TextStyle(fontSize: 14, color: AppTheme.textSecondary),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Icon(Icons.calendar_today_rounded, size: 14, color: AppTheme.textTertiary),
                SizedBox(width: 4),
                Text(
                  _formatDate(announcement['date']),
                  style: TextStyle(fontSize: 12, color: AppTheme.textTertiary),
                ),
                if (announcement['expiry_date'] != null)
                  Row(
                    children: [
                      SizedBox(width: 16),
                      Icon(Icons.timer_rounded, size: 14, color: AppTheme.textTertiary),
                      SizedBox(width: 4),
                      Text(
                        "Expires: ${_formatDate(announcement['expiry_date'])}",
                        style: TextStyle(fontSize: 12, color: AppTheme.textTertiary),
                      ),
                    ],
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(dynamic date) {
    if (date == null) return 'Unknown date';
    try {
      DateTime dateTime = DateTime.parse(date.toString());
      return DateFormat('dd MMM yyyy').format(dateTime);
    } catch (e) {
      return date.toString();
    }
  }

  Widget _buildProductsTab() {
    return RefreshIndicator(
      onRefresh: () async {
        if (isLoggedIn) {
          await _fetchProducts();
          await _fetchPurchaseHistory();
        }
      },
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Column(
                children: [
                  _buildStatsCard(),
                  SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Available Products",
                        style: GoogleFonts.inter(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.primaryGreen,
                        ),
                      ),
                      Text(
                        "${products.length} items",
                        style: TextStyle(
                          fontSize: 14,
                          color: AppTheme.textTertiary,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                ],
              ),
            ),
          ),
          if (products.isNotEmpty)
            SliverList(
              delegate: SliverChildBuilderDelegate(
                    (context, index) {
                  return Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: _buildProductCard(products[index]),
                  );
                },
                childCount: products.length,
              ),
            )
          else
            SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.shopping_bag_outlined, size: 60, color: AppTheme.textTertiary),
                    SizedBox(height: 16),
                    Text(
                      "No products available",
                      style: TextStyle(fontSize: 16, color: AppTheme.textTertiary),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Check back later for new products",
                      style: TextStyle(fontSize: 14, color: AppTheme.textTertiary),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAnnouncementsTab() {
    return RefreshIndicator(
      onRefresh: _fetchAnnouncements,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Column(
                children: [
                  _buildStatsCard(),
                  SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Latest Announcements",
                        style: GoogleFonts.inter(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.primaryGreen,
                        ),
                      ),
                      Text(
                        "${announcements.length} announcements",
                        style: TextStyle(
                          fontSize: 14,
                          color: AppTheme.textTertiary,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                ],
              ),
            ),
          ),
          if (announcements.isNotEmpty)
            SliverList(
              delegate: SliverChildBuilderDelegate(
                    (context, index) {
                  return Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: _buildAnnouncementCard(announcements[index]),
                  );
                },
                childCount: announcements.length,
              ),
            )
          else
            SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.announcement_outlined, size: 60, color: AppTheme.textTertiary),
                    SizedBox(height: 16),
                    Text(
                      "No announcements yet",
                      style: TextStyle(fontSize: 16, color: AppTheme.textTertiary),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Check back later for updates",
                      style: TextStyle(fontSize: 14, color: AppTheme.textTertiary),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: AppTheme.professionalTheme,
      child: Scaffold(
        backgroundColor: AppTheme.backgroundColor,
        appBar: AppBar(
          backgroundColor: Colors.white, // White background
          elevation: 0,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "PineTrack",
                style: GoogleFonts.montserrat(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.primaryGreen, // Green text
                  letterSpacing: -0.3,
                ),
              ),
              Text(
                "Customer Dashboard",
                style: GoogleFonts.inter(
                  fontSize: 12,
                  color: AppTheme.textTertiary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          actions: [
            // Logout Button
            IconButton(
              icon: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.primaryGreen, // Green background
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.logout_rounded,
                  size: 22,
                  color: Colors.white, // White icon
                ),
              ),
              onPressed: _logoutUser,
              tooltip: "Logout",
            ),

            // Profile Button
            IconButton(
              icon: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.primaryGreen, // Green background
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.person_rounded,
                  size: 22,
                  color: Colors.white, // White icon
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CustomerProfile(
                      customerId: customerId,
                      customerName: customerName,
                    ),
                  ),
                ).then((_) => _initializeUserData());
              },
              tooltip: "Profile",
            ),

            // Purchase History Button
            IconButton(
              icon: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: isLoggedIn ? AppTheme.primaryGreen : AppTheme.textTertiary.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.history_rounded,
                  size: 22,
                  color: isLoggedIn ? Colors.white : Colors.white.withOpacity(0.5),
                ),
              ),
              onPressed: isLoggedIn
                  ? () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CustomerPurchaseHistory(
                      customerId: customerId,
                    ),
                  ),
                ).then((_) => _fetchPurchaseHistory());
              }
                  : null,
              tooltip: "Purchase History",
            ),

            // Refresh Button
            IconButton(
              icon: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.primaryGreen, // Green background
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.refresh_rounded,
                  size: 22,
                  color: Colors.white, // White icon
                ),
              ),
              onPressed: _loadAllData,
              tooltip: "Refresh",
            ),
          ],
        ),
        body: isLoading
            ? Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(
                color: AppTheme.primaryGreen,
              ),
              SizedBox(height: 16),
              Text(
                "Loading dashboard...",
                style: TextStyle(color: AppTheme.textTertiary),
              ),
            ],
          ),
        )
            : _selectedIndex == 0
            ? _buildProductsTab()
            : _buildAnnouncementsTab(),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 8,
                offset: Offset(0, -2),
              ),
            ],
          ),
          child: BottomNavigationBar(
            currentIndex: _selectedIndex,
            onTap: (index) => setState(() => _selectedIndex = index),
            backgroundColor: Colors.white,
            selectedItemColor: AppTheme.primaryGreen,
            unselectedItemColor: AppTheme.textTertiary,
            selectedLabelStyle: TextStyle(fontWeight: FontWeight.w600),
            type: BottomNavigationBarType.fixed,
            elevation: 4,
            items: [
              BottomNavigationBarItem(
                icon: Icon(Icons.shopping_bag_outlined),
                activeIcon: Icon(Icons.shopping_bag_rounded),
                label: 'Products',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.announcement_outlined),
                activeIcon: Icon(Icons.announcement_rounded),
                label: 'Announcements',
              ),
            ],
          ),
        ),
      ),
    );
  }
}