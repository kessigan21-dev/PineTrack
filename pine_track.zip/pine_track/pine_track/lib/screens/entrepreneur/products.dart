import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'add_product.dart';

class SellerProducts extends StatefulWidget {
  final String sellerId;
  const SellerProducts({Key? key, required this.sellerId}) : super(key: key);

  @override
  State<SellerProducts> createState() => _SellerProductsState();
}

class _SellerProductsState extends State<SellerProducts> {
  List products = [];
  bool isLoading = true;
  final String apiUrl = "http://192.168.56.1/pine_track_api/get_products.php";
  final String deleteUrl = "http://192.168.56.1/pine_track_api/delete_product.php";

  @override
  void initState() {
    super.initState();
    fetchProducts();
  }

  void fetchProducts() async {
    try {
      var response = await http.get(
        Uri.parse("$apiUrl?seller_id=${widget.sellerId}"),
      );

      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          products = data['products'];
          isLoading = false;
        });
      } else {
        Fluttertoast.showToast(msg: data['message']);
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  void deleteProduct(int id) async {
    bool confirm = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Confirm Delete"),
        content: Text("Are you sure you want to delete this product?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text("Delete", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      var response = await http.post(
        Uri.parse(deleteUrl),
        body: {
          'product_id': id.toString(),
          'seller_id': widget.sellerId,
        },
      );

      var data = json.decode(response.body);
      Fluttertoast.showToast(msg: data['message']);

      if (data['status'] == 'success') {
        fetchProducts();
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
    }
  }

  void editProduct(Map<String, dynamic> product) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddProductScreen(
          sellerId: widget.sellerId,
          product: product,
        ),
      ),
    ).then((value) {
      if (value == true) fetchProducts();
    });
  }

  Color getProductTypeColor(String type) {
    switch (type) {
      case 'pineapple':
        return Colors.orange;
      default:
        return Colors.blue;
    }
  }

  String getProductTypeIcon(String type) {
    switch (type) {
      case 'pineapple':
        return '🍍';
      default:
        return '📦';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Products"),
        backgroundColor: Color(0xFF4CAF50),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : products.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_bag, size: 80, color: Colors.grey),
            SizedBox(height: 20),
            Text(
              "No products yet",
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
            SizedBox(height: 10),
            Text(
              "Tap the + button to add your first product",
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
          ],
        ),
      )
          : RefreshIndicator(
        onRefresh: () async {
          fetchProducts();
        },
        child: ListView.builder(
          padding: EdgeInsets.all(16),
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            bool isPineapple = product['product_type'] == 'pineapple';
            bool isAvailable = product['is_available'] == 1;
            String imageUrl = product['image_url'] ?? '';

            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              elevation: 4,
              margin: EdgeInsets.only(bottom: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Product Image Section
                  Container(
                    height: 200,
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        topRight: Radius.circular(15),
                      ),
                      image: imageUrl.isNotEmpty
                          ? DecorationImage(
                        image: NetworkImage(imageUrl),
                        fit: BoxFit.cover,
                      )
                          : null,
                    ),
                    child: imageUrl.isEmpty
                        ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            isPineapple
                                ? Icons.local_florist
                                : Icons.shopping_bag,
                            size: 60,
                            color: Colors.grey[300],
                          ),
                          SizedBox(height: 8),
                          Text(
                            "No Image",
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    )
                        : null,
                  ),

                  // Product Info Section
                  Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Header Row
                        Row(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: getProductTypeColor(
                                        product['product_type']),
                                    borderRadius:
                                    BorderRadius.circular(20),
                                  ),
                                  child: Row(
                                    children: [
                                      Text(
                                        getProductTypeIcon(
                                            product['product_type']),
                                        style:
                                        TextStyle(fontSize: 14),
                                      ),
                                      SizedBox(width: 4),
                                      Text(
                                        product['product_type']
                                            .toString()
                                            .toUpperCase() ??
                                            'OTHER',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 8),
                                if (!isAvailable)
                                  Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: Colors.red,
                                      borderRadius:
                                      BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      'OUT OF STOCK',
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                if (product['stock_quantity'] != null && product['stock_quantity'] <= 5)
                                  Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: Colors.orange,
                                      borderRadius:
                                      BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      'LOW STOCK',
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                            Text(
                              "RM ${double.parse(product['price'].toString()).toStringAsFixed(2)}/${product['unit'] ?? 'unit'}",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF4CAF50),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 12),

                        // Product Name
                        Text(
                          product['name'] ?? 'Unnamed Product',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        SizedBox(height: 8),

                        // Description
                        if (product['description'] != null)
                          Text(
                            product['description'],
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 14,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),

                        SizedBox(height: 12),

                        // Details Row
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            if (isPineapple &&
                                product['weight_kg'] != null)
                              _buildDetailChip(
                                Icons.scale,
                                "${product['weight_kg']} kg",
                                color: Colors.blue[100],
                              ),
                            if (product['stock_quantity'] != null)
                              _buildDetailChip(
                                Icons.inventory,
                                "Stock: ${product['stock_quantity']}",
                                color: product['stock_quantity'] > 5
                                    ? Colors.green[100]
                                    : Colors.orange[100],
                              ),
                            if (product['harvest_date'] != null)
                              _buildDetailChip(
                                Icons.calendar_today,
                                "Harvest: ${product['harvest_date'].toString().substring(0, 10)}",
                                color: Colors.purple[100],
                              ),
                            if (product['category'] != null)
                              _buildDetailChip(
                                Icons.category,
                                product['category'],
                                color: Colors.cyan[100],
                              ),
                          ],
                        ),

                        SizedBox(height: 16),

                        // Contact Info
                        if (product['contact_info'] != null)
                          Container(
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.blue[50],
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.phone, size: 18, color: Colors.blue),
                                SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Contact for Orders:",
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey[600],
                                        ),
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        product['contact_info'],
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.blue[800],
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),

                        SizedBox(height: 16),

                        // Promotion Banner
                        if (product['promotion'] != null &&
                            product['promotion'].isNotEmpty)
                          Container(
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.amber[50]!,
                                  Colors.orange[50]!,
                                ],
                              ),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: Colors.orange[200]!),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.local_offer,
                                    color: Colors.orange[800]),
                                SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    product['promotion'],
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: Colors.orange[800],
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),

                  // Action Buttons (Only Edit & Delete)
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey[50],
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(15),
                        bottomRight: Radius.circular(15),
                      ),
                      border: Border(
                        top: BorderSide(
                          color: Colors.grey[200]!,
                          width: 1,
                        ),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        ElevatedButton.icon(
                          onPressed: () => editProduct(product),
                          icon: Icon(Icons.edit, size: 18),
                          label: Text("Edit Product"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            foregroundColor: Colors.white,
                          ),
                        ),
                        SizedBox(width: 8),
                        IconButton(
                          icon: Icon(Icons.delete,
                              color: Colors.red),
                          onPressed: () =>
                              deleteProduct(product['id']),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildDetailChip(IconData icon, String text, {Color? color}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color ?? Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.grey[700]),
          SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey[800],
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}