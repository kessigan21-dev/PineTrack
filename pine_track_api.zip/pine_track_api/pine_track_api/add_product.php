<?php
header('Content-Type: application/json');
include 'config.php';

// Required fields
$seller_id = $_POST['seller_id'] ?? '';
$name = $_POST['name'] ?? '';
$price = $_POST['price'] ?? '';
$product_type = $_POST['product_type'] ?? 'other';

// Optional fields with proper null handling
$weight_kg = !empty($_POST['weight_kg']) ? $_POST['weight_kg'] : NULL;
$promotion = !empty($_POST['promotion']) ? $_POST['promotion'] : NULL;
$description = !empty($_POST['description']) ? $_POST['description'] : NULL;
$contact_info = !empty($_POST['contact_info']) ? $_POST['contact_info'] : NULL;
$stock_quantity = !empty($_POST['stock_quantity']) ? (int)$_POST['stock_quantity'] : 0;
$category = !empty($_POST['category']) ? $_POST['category'] : NULL;
$unit = !empty($_POST['unit']) ? $_POST['unit'] : 'kg';
$harvest_date = !empty($_POST['harvest_date']) ? $_POST['harvest_date'] : NULL;
$image_url = !empty($_POST['image_url']) ? $_POST['image_url'] : NULL;
$is_available = isset($_POST['is_available']) ? (int)$_POST['is_available'] : 1;

// Debug - uncomment to see what's being received
// file_put_contents('debug.txt', print_r($_POST, true));

if(empty($seller_id) || empty($name) || empty($price)){
    echo json_encode(['status'=>'error', 'message'=>'Name, price, and product type are required']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO products (
    seller_id, 
    name, 
    product_type, 
    price, 
    weight_kg, 
    promotion, 
    description, 
    contact_info, 
    stock_quantity, 
    category, 
    unit,
    harvest_date,
    image_url,
    is_available
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

// Convert weight_kg to float or null
$weight_kg_value = ($weight_kg !== NULL) ? (float)$weight_kg : NULL;

$stmt->bind_param(
    "issdssssissssi", 
    $seller_id, 
    $name, 
    $product_type, 
    $price, 
    $weight_kg_value, 
    $promotion, 
    $description, 
    $contact_info, 
    $stock_quantity, 
    $category, 
    $unit,
    $harvest_date,
    $image_url,
    $is_available
);

if($stmt->execute()){
    $product_id = $stmt->insert_id;
    echo json_encode([
        'status'=>'success', 
        'message'=>'Product added successfully',
        'product_id' => $product_id
    ]);
} else {
    echo json_encode(['status'=>'error', 'message'=>'Failed to add product: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>