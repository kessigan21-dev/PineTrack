<?php
header('Content-Type: application/json');
include 'config.php';

$product_id = $_POST['product_id'] ?? '';
$seller_id = $_POST['seller_id'] ?? '';

if(empty($product_id) || empty($seller_id)){
    echo json_encode(['status'=>'error', 'message'=>'Required fields missing']);
    exit;
}

$stmt = $conn->prepare("DELETE FROM products WHERE id=? AND seller_id=?");
$stmt->bind_param("ii", $product_id, $seller_id);

if($stmt->execute()){
    echo json_encode(['status'=>'success', 'message'=>'Product deleted successfully']);
} else {
    echo json_encode(['status'=>'error', 'message'=>'Failed to delete product']);
}

$stmt->close();
$conn->close();
?>