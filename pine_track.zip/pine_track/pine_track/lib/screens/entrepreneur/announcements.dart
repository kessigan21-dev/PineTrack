import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'add_announcement.dart';
import 'package:intl/intl.dart';

class SellerAnnouncements extends StatefulWidget {
  final String sellerId;
  const SellerAnnouncements({Key? key, required this.sellerId}) : super(key: key);

  @override
  State<SellerAnnouncements> createState() => _SellerAnnouncementsState();
}

class _SellerAnnouncementsState extends State<SellerAnnouncements> {
  List announcements = [];
  bool isLoading = true;
  final String apiUrl = "http://192.168.56.1/pine_track_api/get_announcements.php";
  final String deleteUrl = "http://192.168.56.1/pine_track_api/delete_announcement.php";

  @override
  void initState() {
    super.initState();
    fetchAnnouncements();
  }

  void fetchAnnouncements() async {
    try {
      var response = await http.get(
        Uri.parse("$apiUrl?seller_id=${widget.sellerId}"),
      );

      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          announcements = data['announcements'];
          isLoading = false;
        });
      } else {
        Fluttertoast.showToast(msg: data['message']);
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  void deleteAnnouncement(int id) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Delete Announcement"),
        content: const Text("Are you sure you want to delete this announcement?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              try {
                var response = await http.post(
                  Uri.parse(deleteUrl),
                  body: {
                    'announcement_id': id.toString(),
                    'seller_id': widget.sellerId,
                  },
                );

                var data = json.decode(response.body);
                Fluttertoast.showToast(msg: data['message']);

                if (data['status'] == 'success') {
                  fetchAnnouncements();
                }
              } catch (e) {
                Fluttertoast.showToast(msg: "Error: $e");
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text("Delete"),
          ),
        ],
      ),
    );
  }

  Color _getTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'promotion':
        return const Color(0xFF4CAF50);
      case 'event':
        return const Color(0xFF2196F3);
      case 'maintenance':
        return const Color(0xFFFF9800);
      case 'important':
        return const Color(0xFFF44336);
      default:
        return const Color(0xFF9C27B0);
    }
  }

  IconData _getTypeIcon(String type) {
    switch (type.toLowerCase()) {
      case 'promotion':
        return Icons.local_offer;
      case 'event':
        return Icons.event;
      case 'maintenance':
        return Icons.build;
      case 'important':
        return Icons.warning;
      default:
        return Icons.announcement;
    }
  }

  String _formatDate(String? date) {
    if (date == null) return 'No date';
    try {
      final parsedDate = DateTime.parse(date);
      return DateFormat('MMM dd, yyyy').format(parsedDate);
    } catch (e) {
      return date;
    }
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(60),
            ),
            child: const Icon(
              Icons.announcement,
              size: 60,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            "No Announcements Yet",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            "Tap the + button to create your first announcement",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnnouncementCard(Map<String, dynamic> item) {
    final isExpired = item['status'] == 'expired';

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: isExpired ? Colors.grey.shade300 : Colors.green.shade100,
          width: 1,
        ),
      ),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: isExpired
              ? LinearGradient(
            colors: [Colors.grey.shade50, Colors.grey.shade100],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          )
              : null,
          color: isExpired ? null : Colors.white,
        ),
        child: Stack(
          children: [
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              child: Container(
                width: 6,
                decoration: BoxDecoration(
                  color: _getTypeColor(item['type'] ?? 'General'),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    bottomLeft: Radius.circular(16),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _getTypeColor(item['type'] ?? 'General').withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: _getTypeColor(item['type'] ?? 'General').withOpacity(0.3),
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              _getTypeIcon(item['type'] ?? 'General'),
                              size: 14,
                              color: _getTypeColor(item['type'] ?? 'General'),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              item['type'] ?? 'General',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: _getTypeColor(item['type'] ?? 'General'),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      if (isExpired)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.timelapse, size: 12, color: Colors.grey),
                              SizedBox(width: 4),
                              Text(
                                'Expired',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.grey,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    item['title'] ?? '',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: isExpired ? Colors.grey : Colors.green.shade900,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    item['details'] ?? '',
                    style: TextStyle(
                      fontSize: 14,
                      color: isExpired ? Colors.grey.shade600 : Colors.grey.shade800,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Icon(
                        Icons.calendar_today,
                        size: 14,
                        color: Colors.grey.shade500,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        _formatDate(item['date']),
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),
                      const SizedBox(width: 16),
                      if (item['expiry_date'] != null)
                        Row(
                          children: [
                            Icon(
                              Icons.timelapse,
                              size: 14,
                              color: Colors.grey.shade500,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              'Expires: ${_formatDate(item['expiry_date'])}',
                              style: TextStyle(
                                fontSize: 12,
                                color: isExpired ? Colors.red.shade600 : Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      const Spacer(),
                      IconButton(
                        icon: Icon(
                          Icons.delete_outline,
                          size: 20,
                          color: Colors.grey.shade500,
                        ),
                        onPressed: () => deleteAnnouncement(item['id']),
                        tooltip: 'Delete',
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: isLoading
          ? const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
        ),
      )
          : RefreshIndicator(
        onRefresh: () async => fetchAnnouncements(),
        backgroundColor: Colors.white,
        color: Colors.green,
        child: announcements.isEmpty
            ? _buildEmptyState()
            : ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 16),
          itemCount: announcements.length,
          itemBuilder: (context, index) {
            return _buildAnnouncementCard(announcements[index]);
          },
        ),
      ),
    );
  }
}