<?php
header('Content-Type: application/json');
include 'config.php';

$seller_id = $_GET['seller_id'] ?? '';
$range = $_GET['range'] ?? '7d'; // Get time range from request

if(empty($seller_id)){
    echo json_encode(['status'=>'error', 'message'=>'Seller ID required']);
    exit;
}

// Determine date range based on selection
$date_condition = '';
switch($range) {
    case '30d':
        $date_condition = "AND transaction_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
        break;
    case '90d':
        $date_condition = "AND transaction_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)";
        break;
    default: // 7d
        $date_condition = "AND transaction_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
}

$analytics = [];

// 1. Total Revenue for this seller
$stmt = $conn->prepare("
    SELECT COALESCE(SUM(total_price), 0) as total_revenue 
    FROM sales_transactions 
    WHERE seller_id = ? AND status = 'completed'
");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$totalRev = $result->fetch_assoc()['total_revenue'] ?? 0;
$analytics['total_revenue'] = number_format($totalRev, 2);

// 2. Total Products Sold for this seller
$stmt = $conn->prepare("
    SELECT COALESCE(SUM(quantity), 0) as total_products_sold 
    FROM sales_transactions 
    WHERE seller_id = ? AND status = 'completed'
");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$analytics['total_products_sold'] = $result->fetch_assoc()['total_products_sold'] ?? 0;

// 3. Total Number of Orders
$stmt = $conn->prepare("
    SELECT COUNT(*) as total_orders 
    FROM sales_transactions 
    WHERE seller_id = ? AND status = 'completed'
");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$analytics['total_orders'] = $result->fetch_assoc()['total_orders'] ?? 0;

// 4. Average Sale Value for this seller
$avgSale = ($analytics['total_products_sold'] > 0 && $totalRev > 0) 
    ? $totalRev / $analytics['total_products_sold'] 
    : 0;
$analytics['average_sale'] = number_format($avgSale, 2);

// 5. Top Selling Product for this seller
$stmt = $conn->prepare("
    SELECT p.name, COALESCE(SUM(st.quantity), 0) as total_sold
    FROM products p
    LEFT JOIN sales_transactions st ON p.id = st.product_id 
        AND st.seller_id = ? 
        AND st.status = 'completed'
    WHERE p.seller_id = ?
    GROUP BY p.id
    ORDER BY total_sold DESC
    LIMIT 1
");
$stmt->bind_param("ii", $seller_id, $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$topProduct = $result->fetch_assoc();
$analytics['top_product'] = $topProduct['name'] ?? 'No sales yet';

// 6. Daily Sales for selected time range
$stmt = $conn->prepare("
    SELECT 
        DATE(transaction_date) as date,
        COALESCE(SUM(total_price), 0) as revenue,
        COALESCE(SUM(quantity), 0) as quantity
    FROM sales_transactions 
    WHERE seller_id = ? 
    AND status = 'completed'
    $date_condition
    GROUP BY DATE(transaction_date)
    ORDER BY date
");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$dailySales = [];
while($row = $result->fetch_assoc()){
    $dailySales[] = $row;
}
$analytics['daily_sales'] = $dailySales;

// 7. Best Day (highest revenue day)
if (!empty($dailySales)) {
    $bestDay = max(array_column($dailySales, 'revenue'));
    $bestDayKey = array_search($bestDay, array_column($dailySales, 'revenue'));
    $analytics['best_day'] = $dailySales[$bestDayKey];
} else {
    $analytics['best_day'] = ['date' => 'N/A', 'revenue' => 0];
}

// 8. Revenue growth (compare current period with previous period)
$stmt = $conn->prepare("
    SELECT 
        COALESCE(SUM(CASE 
            WHEN transaction_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY) 
                 AND transaction_date < CURDATE() 
            THEN total_price ELSE 0 
        END), 0) as current_period,
        COALESCE(SUM(CASE 
            WHEN transaction_date >= DATE_SUB(CURDATE(), INTERVAL ? * 2 DAY) 
                 AND transaction_date < DATE_SUB(CURDATE(), INTERVAL ? DAY) 
            THEN total_price ELSE 0 
        END), 0) as previous_period
    FROM sales_transactions 
    WHERE seller_id = ? AND status = 'completed'
");
$days = ($range == '7d') ? 7 : (($range == '30d') ? 30 : 90);
$stmt->bind_param("iiii", $days, $days, $days, $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$growthData = $result->fetch_assoc();

$current = $growthData['current_period'] ?? 0;
$previous = $growthData['previous_period'] ?? 0;

if ($previous > 0) {
    $growth = (($current - $previous) / $previous) * 100;
    $analytics['revenue_growth'] = round($growth, 1);
} else {
    $analytics['revenue_growth'] = $current > 0 ? 100 : 0;
}

// 9. Sales by Category
$stmt = $conn->prepare("
    SELECT 
        COALESCE(p.category, 'Other') as category,
        COALESCE(SUM(st.total_price), 0) as total_revenue,
        COALESCE(SUM(st.quantity), 0) as total_quantity
    FROM products p
    LEFT JOIN sales_transactions st ON p.id = st.product_id 
        AND st.seller_id = ? 
        AND st.status = 'completed'
    WHERE p.seller_id = ?
    GROUP BY COALESCE(p.category, 'Other')
    ORDER BY total_revenue DESC
");
$stmt->bind_param("ii", $seller_id, $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$categoryDistribution = [];
while($row = $result->fetch_assoc()){
    $categoryDistribution[] = $row;
}
$analytics['category_distribution'] = $categoryDistribution;

// 10. Customer Insights
// Repeat Customers (customers with >1 purchase)
$stmt = $conn->prepare("
    SELECT COUNT(*) as repeat_customers
    FROM (
        SELECT customer_id 
        FROM sales_transactions 
        WHERE seller_id = ? AND status = 'completed'
        GROUP BY customer_id 
        HAVING COUNT(*) > 1
    ) as repeat_customers
");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$analytics['repeat_customers'] = $result->fetch_assoc()['repeat_customers'] ?? 0;

// Total Unique Customers
$stmt = $conn->prepare("
    SELECT COUNT(DISTINCT customer_id) as total_customers
    FROM sales_transactions 
    WHERE seller_id = ? AND status = 'completed'
");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$totalCustomers = $result->fetch_assoc()['total_customers'] ?? 0;
$analytics['new_customers'] = $totalCustomers - $analytics['repeat_customers'];

// Average Customer Spend
$avgSpend = ($totalCustomers > 0 && $totalRev > 0) 
    ? $totalRev / $totalCustomers 
    : 0;
$analytics['average_customer_spend'] = number_format($avgSpend, 2);

// Top Customer
$stmt = $conn->prepare("
    SELECT 
        c.name,
        COALESCE(SUM(st.total_price), 0) as total_spent,
        COUNT(*) as total_orders
    FROM sales_transactions st
    JOIN customers c ON st.customer_id = c.id
    WHERE st.seller_id = ? AND st.status = 'completed'
    GROUP BY st.customer_id
    ORDER BY total_spent DESC
    LIMIT 1
");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$topCustomer = $result->fetch_assoc();
$analytics['top_customer'] = $topCustomer;

// 11. Recent Sales (last 10)
$stmt = $conn->prepare("
    SELECT 
        st.*,
        p.name as product_name,
        c.name as customer_name,
        DATE_FORMAT(st.transaction_date, '%Y-%m-%d %H:%i') as date
    FROM sales_transactions st
    JOIN products p ON st.product_id = p.id
    LEFT JOIN customers c ON st.customer_id = c.id
    WHERE st.seller_id = ? 
    AND st.status = 'completed'
    ORDER BY st.transaction_date DESC
    LIMIT 10
");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$recentSales = [];
while($row = $result->fetch_assoc()){
    $recentSales[] = $row;
}
$analytics['recent_sales'] = $recentSales;

// 12. Product Performance with stock info
$stmt = $conn->prepare("
    SELECT 
        p.name,
        p.price,
        p.stock_quantity as stock,
        COALESCE(SUM(st.quantity), 0) as total_sold,
        COALESCE(SUM(st.total_price), 0) as total_revenue
    FROM products p
    LEFT JOIN sales_transactions st ON p.id = st.product_id 
        AND st.status = 'completed'
    WHERE p.seller_id = ?
    GROUP BY p.id
    ORDER BY total_sold DESC
");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$productPerformance = [];
while($row = $result->fetch_assoc()){
    $productPerformance[] = $row;
}
$analytics['product_performance'] = $productPerformance;

$analytics['status'] = 'success';
$analytics['time_range'] = $range;
echo json_encode($analytics);

$stmt->close();
$conn->close();
?>