<?php
header('Content-Type: application/json');
include 'config.php';

if (!isset($_GET['seller_id']) || empty($_GET['seller_id'])) {
    // If no seller_id provided, return all products for all sellers
    $stmt = $conn->prepare("
        SELECT 
            p.id, 
            p.seller_id, 
            p.name, 
            p.product_type, 
            p.price, 
            p.weight_kg, 
            p.promotion, 
            p.description, 
            p.contact_info, 
            p.stock_quantity, 
            p.image_url, 
            p.category, 
            p.harvest_date, 
            p.is_available, 
            p.unit,
            p.created_at,
            e.name as seller_name,
            e.shop_info
        FROM products p
        JOIN entrepreneurs e ON p.seller_id = e.id
        WHERE p.is_available = 1 
        ORDER BY p.created_at DESC
    ");
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $products = [];
    while($row = $result->fetch_assoc()){
        $products[] = $row;
    }
    
    echo json_encode(['status'=>'success', 'products'=>$products]);
    $stmt->close();
    $conn->close();
    exit;
}

// If seller_id IS provided, return only that seller's products
$seller_id = $_GET['seller_id'];

$stmt = $conn->prepare("
    SELECT 
        p.id, 
        p.seller_id, 
        p.name, 
        p.product_type, 
        p.price, 
        p.weight_kg, 
        p.promotion, 
        p.description, 
        p.contact_info, 
        p.stock_quantity, 
        p.image_url, 
        p.category, 
        p.harvest_date, 
        p.is_available, 
        p.unit,
        p.created_at,
        e.name as seller_name,
        e.shop_info
    FROM products p
    JOIN entrepreneurs e ON p.seller_id = e.id
    WHERE p.seller_id = ? 
    AND p.is_available = 1 
    ORDER BY p.created_at DESC
");

$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();

$products = [];
while($row = $result->fetch_assoc()){
    $products[] = $row;
}

echo json_encode(['status'=>'success', 'products'=>$products]);

$stmt->close();
$conn->close();
?>