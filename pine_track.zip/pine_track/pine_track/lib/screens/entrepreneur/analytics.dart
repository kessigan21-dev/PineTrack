import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fl_chart/fl_chart.dart';

// ==================== ALL TRANSACTIONS SCREEN ====================
class AllTransactionsScreen extends StatelessWidget {
  final String sellerId;

  const AllTransactionsScreen({Key? key, required this.sellerId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "All Transactions",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Color(0xFF4CAF50),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: FutureBuilder(
        future: _fetchAllTransactions(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text("Error loading transactions"));
          }

          List transactions = snapshot.data as List;

          if (transactions.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.receipt_long, size: 60, color: Colors.grey),
                  SizedBox(height: 16),
                  Text(
                    "No transactions yet",
                    style: TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: EdgeInsets.all(16),
            itemCount: transactions.length,
            itemBuilder: (context, index) {
              var transaction = transactions[index];
              return _buildTransactionCard(transaction, index);
            },
          );
        },
      ),
    );
  }

  Future<List> _fetchAllTransactions() async {
    try {
      var response = await http.get(
        Uri.parse("http://192.168.56.1/pine_track_api/get_all_transactions.php?seller_id=$sellerId"),
      );

      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        return data['transactions'] ?? [];
      }
      return [];
    } catch (e) {
      print("Error fetching transactions: $e");
      return [];
    }
  }

  Widget _buildTransactionCard(Map<String, dynamic> transaction, int index) {
    double totalPrice = _parseToDouble(transaction['total_price']);
    int quantity = _parseToInt(transaction['quantity']);
    String date = transaction['date']?.toString() ?? '';
    String productName = transaction['product_name']?.toString() ?? 'Unknown';
    String customerName = transaction['customer_name']?.toString() ?? 'Customer';
    String paymentMethod = transaction['payment_method']?.toString() ?? 'Cash';
    String status = transaction['status']?.toString() ?? 'completed';

    // Format date to be more readable
    String formattedDate = '';
    if (date.length >= 10) {
      formattedDate = date.substring(0, 10);
    }

    Color statusColor = Colors.green;
    IconData statusIcon = Icons.check_circle;

    if (status == 'pending') {
      statusColor = Colors.orange;
      statusIcon = Icons.pending;
    } else if (status == 'cancelled') {
      statusColor = Colors.red;
      statusIcon = Icons.cancel;
    }

    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: Text(
                      "#${index + 1}",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        productName,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 4),
                      Text(
                        "Sold to: $customerName",
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Row(
                    children: [
                      Icon(statusIcon, size: 12, color: statusColor),
                      SizedBox(width: 4),
                      Text(
                        status.toUpperCase(),
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: statusColor,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Divider(height: 1, color: Colors.grey[200]),
            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Quantity",
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      "$quantity units",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Payment",
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      paymentMethod.toUpperCase(),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Total",
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      "RM ${totalPrice.toStringAsFixed(2)}",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 8),
            Divider(height: 1, color: Colors.grey[200]),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Transaction Date",
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                Text(
                  formattedDate,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  double _parseToDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) {
      return double.tryParse(value.replaceAll(RegExp(r'[^0-9\.]'), '')) ?? 0.0;
    }
    return 0.0;
  }

  int _parseToInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) {
      return int.tryParse(value.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
    }
    return 0;
  }
}

// ==================== MAIN ANALYTICS SCREEN ====================
class SalesData {
  final String date;
  final double revenue;

  SalesData(this.date, this.revenue);
}

class AnalyticsScreen extends StatefulWidget {
  final String sellerId;
  const AnalyticsScreen({Key? key, required this.sellerId}) : super(key: key);

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  Map<String, dynamic> analyticsData = {};
  bool isLoading = true;
  String _selectedTimeRange = '7d';

  @override
  void initState() {
    super.initState();
    fetchAnalytics();
  }

  void fetchAnalytics() async {
    try {
      var response = await http.get(
        Uri.parse("http://192.168.56.1/pine_track_api/get_analytics.php?seller_id=${widget.sellerId}&range=$_selectedTimeRange"),
      );

      var data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          analyticsData = data;
          isLoading = false;
        });
      }
    } catch (e) {
      print("Analytics Error: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  List<SalesData> _prepareChartData() {
    List<SalesData> chartData = [];
    List dailySales = analyticsData['daily_sales'] ?? [];

    for (var sale in dailySales) {
      if (sale is Map<String, dynamic>) {
        double revenue = _parseToDouble(sale['revenue']);
        String date = sale['date']?.toString() ?? '';
        if (date.length >= 10) {
          date = date.substring(5, 10);
        }
        chartData.add(SalesData(date, revenue));
      }
    }

    return chartData;
  }

  Widget _buildRevenueChart() {
    final chartData = _prepareChartData();

    if (chartData.isEmpty) {
      return Container(
        height: 200,
        child: Center(
          child: Text(
            "No sales data available",
            style: TextStyle(color: Colors.grey, fontSize: 16),
          ),
        ),
      );
    }

    double maxRevenue = chartData.map((e) => e.revenue).reduce((a, b) => a > b ? a : b);
    double yMax = maxRevenue * 1.2;

    return Container(
      height: 200,
      padding: EdgeInsets.all(16),
      child: LineChart(
        LineChartData(
          gridData: FlGridData(show: true),
          titlesData: FlTitlesData(
            show: true,
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  final index = value.toInt();
                  if (index >= 0 && index < chartData.length) {
                    return Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                        chartData[index].date,
                        style: TextStyle(fontSize: 10),
                      ),
                    );
                  }
                  return Text('');
                },
                reservedSize: 32,
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  return Padding(
                    padding: EdgeInsets.only(right: 4),
                    child: Text(
                      'RM ${value.toInt()}',
                      style: TextStyle(fontSize: 10),
                    ),
                  );
                },
                reservedSize: 40,
              ),
            ),
            topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          borderData: FlBorderData(
            show: true,
            border: Border.all(color: Colors.grey[300]!),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: chartData.asMap().entries.map((entry) {
                return FlSpot(
                  entry.key.toDouble(),
                  entry.value.revenue,
                );
              }).toList(),
              isCurved: true,
              color: Color(0xFF4CAF50),
              barWidth: 3,
              belowBarData: BarAreaData(
                show: true,
                color: Color(0xFF4CAF50).withOpacity(0.1),
              ),
              dotData: FlDotData(show: false),
            ),
          ],
          minY: 0,
          maxY: yMax,
        ),
      ),
    );
  }

  Widget _buildTimeRangeSelector() {
    return Container(
      padding: EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildTimeRangeButton('7d', '7D'),
          SizedBox(width: 4),
          _buildTimeRangeButton('30d', '30D'),
          SizedBox(width: 4),
          _buildTimeRangeButton('90d', '90D'),
        ],
      ),
    );
  }

  Widget _buildTimeRangeButton(String value, String label) {
    bool isSelected = _selectedTimeRange == value;
    return InkWell(
      onTap: () {
        setState(() {
          _selectedTimeRange = value;
          isLoading = true;
        });
        fetchAnalytics();
      },
      borderRadius: BorderRadius.circular(6),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? Color(0xFF4CAF50) : Colors.transparent,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey[700],
            fontWeight: FontWeight.w500,
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  double _parseToDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) {
      return double.tryParse(value.replaceAll(RegExp(r'[^0-9\.]'), '')) ?? 0.0;
    }
    return 0.0;
  }

  int _parseToInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) {
      return int.tryParse(value.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
    }
    return 0;
  }

  String _calculateGrowth(dynamic growth) {
    if (growth == null) return '';
    double growthValue = _parseToDouble(growth);
    if (growthValue > 0) {
      return '+${growthValue.toStringAsFixed(1)}%';
    } else if (growthValue < 0) {
      return '${growthValue.toStringAsFixed(1)}%';
    }
    return '';
  }

  String _getInitials(String name) {
    if (name.isEmpty) return 'N/A';
    List<String> parts = name.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    } else if (name.length >= 2) {
      return name.substring(0, 2).toUpperCase();
    }
    return name.toUpperCase();
  }

  // CUSTOMER INSIGHTS SECTION - ENLARGED
  Widget _buildCustomerInsightsSection() {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        constraints: BoxConstraints(
          minHeight: 300,
          maxHeight: 450, // Add max height constraint
        ),
        child: Padding(
          padding: EdgeInsets.all(12), // Further reduced padding
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min, // Important: Use min to prevent overflow
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Customer Insights",
                    style: TextStyle(
                      fontSize: 16, // Further reduced
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.group, size: 12, color: Colors.blue),
                        SizedBox(width: 4),
                        Text(
                          "${_parseToInt(analyticsData['repeat_customers'] ?? 0) + _parseToInt(analyticsData['new_customers'] ?? 0)}",
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                            color: Colors.blue,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 12),

              // Customer Stats Grid - FIXED WITH BETTER CONSTRAINTS
              GridView.count(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                childAspectRatio: 1.2, // More compact aspect ratio
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                children: [
                  _buildCustomerInsightCard(
                    "Repeat",
                    _parseToInt(analyticsData['repeat_customers'] ?? 0).toString(),
                    Icons.group,
                    Colors.green,
                    ">1 purchase",
                  ),
                  _buildCustomerInsightCard(
                    "New",
                    _parseToInt(analyticsData['new_customers'] ?? 0).toString(),
                    Icons.person_add,
                    Colors.blue,
                    "First-time",
                  ),
                  _buildCustomerInsightCard(
                    "Avg. Order",
                    "RM${_parseToDouble(analyticsData['average_customer_spend'] ?? 0).toStringAsFixed(0)}",
                    Icons.shopping_bag,
                    Colors.orange,
                    "Per customer",
                  ),
                  _buildCustomerInsightCard(
                    "Top Cust",
                    (analyticsData['top_customer'] is Map && analyticsData['top_customer']['name'] != null)
                        ? _getInitials(analyticsData['top_customer']['name']?.toString() ?? 'N/A')
                        : 'N/A',
                    Icons.star,
                    Colors.purple,
                    analyticsData['top_customer'] is Map && analyticsData['top_customer']['total_spent'] != null
                        ? "RM${_parseToDouble(analyticsData['top_customer']['total_spent']).toStringAsFixed(0)}"
                        : "Top spender",
                  ),
                ],
              ),

              SizedBox(height: 12),

              // Top Customer Details - COMPACT VERSION
              if (analyticsData['top_customer'] is Map && analyticsData['top_customer']['name'] != null)
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.purple.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.purple.withOpacity(0.1)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CircleAvatar(
                            radius: 16,
                            backgroundColor: Colors.purple.withOpacity(0.1),
                            child: Icon(Icons.person, color: Colors.purple, size: 14),
                          ),
                          SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Top Customer",
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.grey[600],
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  _truncateText(analyticsData['top_customer']['name']?.toString() ?? '', 12),
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey[800],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                "Orders",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.grey[600],
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                "${analyticsData['top_customer']['total_orders'] ?? '0'}",
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.purple,
                                ),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                "Total",
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.grey[600],
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                "RM${_parseToDouble(analyticsData['top_customer']['total_spent'] ?? 0).toStringAsFixed(0)}",
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.purple,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCustomerInsightCard(String title, String value, IconData icon, Color color, String subtitle) {
    return Container(
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Icon(icon, size: 14, color: color),
              ),
              Spacer(),
            ],
          ),
          SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          SizedBox(height: 2),
          Text(
            title,
            style: TextStyle(
              fontSize: 10,
              color: Colors.grey[600],
              height: 1.2,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          SizedBox(height: 2),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 8,
              color: Colors.grey[500],
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  String _truncateText(String text, int maxLength) {
    if (text.length <= maxLength) return text;
    return '${text.substring(0, maxLength)}...';
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color, {String subtitle = ''}) {
    return Expanded(
      child: Container(
        constraints: BoxConstraints(minHeight: 120),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                Spacer(),
                if (subtitle.contains('+'))
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
            if (subtitle.isNotEmpty && !subtitle.contains('+'))
              Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 10,
                    color: Colors.grey[500],
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryChart() {
    List categories = analyticsData['category_distribution'] ?? [];
    if (categories.isEmpty) return SizedBox();

    double totalRevenue = 0;
    for (var cat in categories) {
      totalRevenue += _parseToDouble(cat['total_revenue']);
    }

    return PieChart(
      PieChartData(
        sectionsSpace: 2,
        centerSpaceRadius: 40,
        sections: categories.map((cat) {
          double value = _parseToDouble(cat['total_revenue']);
          double percentage = totalRevenue > 0 ? (value / totalRevenue) * 100 : 0;

          return PieChartSectionData(
            value: value,
            color: _getCategoryColor(cat['category']?.toString() ?? ''),
            radius: 50,
            title: percentage >= 5 ? '${percentage.toStringAsFixed(0)}%' : '',
            titleStyle: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildCategoryLegend() {
    List categories = analyticsData['category_distribution'] ?? [];
    if (categories.isEmpty) return SizedBox();

    return GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 3,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: categories.length,
      itemBuilder: (context, index) {
        var cat = categories[index];
        String categoryName = cat['category']?.toString() ?? 'Other';
        double revenue = _parseToDouble(cat['total_revenue']);

        return Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: _getCategoryColor(categoryName).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: _getCategoryColor(categoryName),
                  shape: BoxShape.circle,
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      categoryName,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      "RM ${revenue.toStringAsFixed(2)}",
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Color _getCategoryColor(String category) {
    Map<String, Color> colorMap = {
      'Fresh': Colors.green,
      'Frozen': Colors.blue,
      'Organic': Colors.orange,
      'Premium': Colors.purple,
      'Bundle': Colors.red,
      'Processed': Colors.teal,
      'Other': Colors.grey,
    };
    return colorMap[category] ?? Colors.grey;
  }

  Widget _buildProductPerformanceItem(Map<String, dynamic> product, int rank) {
    double totalRevenue = _parseToDouble(product['total_revenue']);
    double price = _parseToDouble(product['price']);
    int totalSold = _parseToInt(product['total_sold']);
    int stock = _parseToInt(product['stock']);

    return ListTile(
      contentPadding: EdgeInsets.symmetric(vertical: 4),
      leading: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: _getRankColor(rank),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: Text(
            "#$rank",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ),
      ),
      title: Text(
        product['name']?.toString() ?? 'Unknown',
        style: TextStyle(fontWeight: FontWeight.w500),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        "$totalSold sold • $stock in stock",
        style: TextStyle(fontSize: 11),
      ),
      trailing: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 80),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              "RM ${totalRevenue.toStringAsFixed(2)}",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.green,
                fontSize: 12,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              "RM ${price.toStringAsFixed(2)}/unit",
              style: TextStyle(fontSize: 10, color: Colors.grey),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSaleItem(Map<String, dynamic> sale) {
    double totalPrice = _parseToDouble(sale['total_price']);
    int quantity = _parseToInt(sale['quantity']);

    return Container(
      margin: EdgeInsets.symmetric(vertical: 4),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Icon(
                (sale['payment_method']?.toString() ?? '').toLowerCase().contains('online')
                    ? Icons.credit_card
                    : Icons.money,
                size: 16,
                color: Colors.green,
              ),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  sale['product_name']?.toString() ?? 'Unknown',
                  style: TextStyle(fontWeight: FontWeight.w500),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 2),
                Text(
                  "${sale['customer_name']?.toString() ?? 'Customer'} • Qty: $quantity",
                  style: TextStyle(fontSize: 11, color: Colors.grey[600]),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          ConstrainedBox(
            constraints: BoxConstraints(maxWidth: 80),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  "RM ${totalPrice.toStringAsFixed(2)}",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.green,
                    fontSize: 12,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  (sale['date']?.toString() ?? '').length >= 10
                      ? sale['date'].toString().substring(0, 10)
                      : '',
                  style: TextStyle(fontSize: 10, color: Colors.grey),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getRankColor(int rank) {
    switch (rank) {
      case 1: return Colors.amber[700]!;
      case 2: return Colors.grey[600]!;
      case 3: return Colors.orange[700]!;
      default: return Colors.blue;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Sales Analytics",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Color(0xFF4CAF50),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Overview",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
                _buildTimeRangeSelector(),
              ],
            ),
            SizedBox(height: 16),

            // Top Stats Row
            Row(
              children: [
                _buildStatCard(
                  "Total Revenue",
                  "RM ${_parseToDouble(analyticsData['total_revenue']).toStringAsFixed(2)}",
                  Icons.attach_money,
                  Colors.green,
                  subtitle: _calculateGrowth(analyticsData['revenue_growth']),
                ),
                SizedBox(width: 12),
                _buildStatCard(
                  "Products Sold",
                  "${_parseToInt(analyticsData['total_products_sold'])}",
                  Icons.shopping_cart,
                  Colors.blue,
                  subtitle: "${_parseToInt(analyticsData['total_orders'])} orders",
                ),
              ],
            ),
            SizedBox(height: 12),

            Row(
              children: [
                _buildStatCard(
                  "Avg. Sale Value",
                  "RM ${_parseToDouble(analyticsData['average_sale']).toStringAsFixed(2)}",
                  Icons.bar_chart,
                  Colors.orange,
                  subtitle: "Per transaction",
                ),
                SizedBox(width: 12),
                _buildStatCard(
                  "Best Day",
                  (analyticsData['best_day'] is Map && analyticsData['best_day']['date'] != null)
                      ? "${analyticsData['best_day']['date']?.toString().substring(5) ?? 'N/A'}"
                      : "N/A",
                  Icons.calendar_today,
                  Colors.purple,
                  subtitle: (analyticsData['best_day'] is Map && analyticsData['best_day']['revenue'] != null)
                      ? "RM ${_parseToDouble(analyticsData['best_day']['revenue']).toStringAsFixed(2)}"
                      : "",
                ),
              ],
            ),
            SizedBox(height: 24),

            // Revenue Trend Chart
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Revenue Trend",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Chip(
                          label: Text(
                            _selectedTimeRange == '7d' ? 'Last 7 Days' :
                            _selectedTimeRange == '30d' ? 'Last 30 Days' : 'Last 90 Days',
                          ),
                          backgroundColor: Color(0xFF4CAF50).withOpacity(0.1),
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                    _buildRevenueChart(),
                  ],
                ),
              ),
            ),

            SizedBox(height: 16),

            // Customer Insights - ENLARGED SECTION
            _buildCustomerInsightsSection(),

            SizedBox(height: 16),

            // Sales Distribution Pie Chart
            if ((analyticsData['category_distribution'] as List?)?.isNotEmpty ?? false)
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Sales by Category",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 16),
                      Container(
                        height: 220,
                        child: Column(
                          children: [
                            Container(
                              height: 140,
                              child: _buildCategoryChart(),
                            ),
                            SizedBox(height: 12),
                            Expanded(
                              child: _buildCategoryLegend(),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            SizedBox(height: 16),

            // Top Products
            if ((analyticsData['product_performance'] as List?)?.isNotEmpty ?? false)
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Top Selling Products",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            icon: Icon(Icons.more_vert, color: Colors.grey),
                            onPressed: () {
                              // TODO: Navigate to detailed product analytics
                            },
                          ),
                        ],
                      ),
                      SizedBox(height: 12),
                      ...List.generate(
                        (analyticsData['product_performance']?.length ?? 0).clamp(0, 5),
                            (index) => _buildProductPerformanceItem(
                          analyticsData['product_performance']?[index] ?? {},
                          index + 1,
                        ),
                      ),
                      if ((analyticsData['product_performance']?.length ?? 0) > 5)
                        Padding(
                          padding: EdgeInsets.only(top: 12),
                          child: Align(
                            alignment: Alignment.center,
                            child: GestureDetector(
                              onTap: () {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text("View All Products feature coming soon!"),
                                    backgroundColor: Color(0xFF4CAF50),
                                  ),
                                );
                              },
                              child: Text(
                                "View All ${analyticsData['product_performance']?.length ?? 0} Products →",
                                style: TextStyle(
                                  color: Color(0xFF4CAF50),
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),

            SizedBox(height: 16),

            // Recent Sales
            if ((analyticsData['recent_sales'] as List?)?.isNotEmpty ?? false)
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Recent Transactions",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => AllTransactionsScreen(sellerId: widget.sellerId),
                                ),
                              );
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: Color(0xFF4CAF50).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                children: [
                                  Text(
                                    "View All",
                                    style: TextStyle(
                                      color: Color(0xFF4CAF50),
                                      fontWeight: FontWeight.w500,
                                      fontSize: 12,
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Icon(Icons.arrow_forward, size: 14, color: Color(0xFF4CAF50)),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12),
                      ...List.generate(
                        (analyticsData['recent_sales']?.length ?? 0).clamp(0, 5),
                            (index) => _buildSaleItem(
                          analyticsData['recent_sales']?[index] ?? {},
                        ),
                      ),
                      SizedBox(height: 12),
                      Align(
                        alignment: Alignment.center,
                        child: GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => AllTransactionsScreen(sellerId: widget.sellerId),
                              ),
                            );
                          },
                          child: Text(
                            "View All Transactions →",
                            style: TextStyle(
                              color: Color(0xFF4CAF50),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}