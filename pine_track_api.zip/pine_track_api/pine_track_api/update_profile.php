<?php
header('Content-Type: application/json');
include 'config.php';

// Use 'id' from POST
$id = (int)($_POST['id'] ?? 0);

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$farm_location = $_POST['farm_location'] ?? '';
$shop_info = $_POST['shop_info'] ?? '';
$social_media = $_POST['social_media'] ?? '';

if($id === 0){
    echo json_encode(['status'=>'error','message'=>'ID required']);
    exit;
}

// Check if email already exists for another user
$checkStmt = $conn->prepare("SELECT id FROM entrepreneurs WHERE email=? AND id!=?");
$checkStmt->bind_param("si", $email, $id);
$checkStmt->execute();
$checkStmt->store_result();

if($checkStmt->num_rows > 0){
    echo json_encode(['status'=>'error','message'=>'Email already exists']);
    $checkStmt->close();
    exit;
}
$checkStmt->close();

// Update profile
$stmt = $conn->prepare("
    UPDATE entrepreneurs 
    SET name=?, email=?, phone=?, farm_location=?, shop_info=?, social_media=? 
    WHERE id=?
");
$stmt->bind_param("ssssssi", $name, $email, $phone, $farm_location, $shop_info, $social_media, $id);

if($stmt->execute()){
    echo json_encode(['status'=>'success','message'=>'Profile updated successfully']);
}else{
    echo json_encode(['status'=>'error','message'=>'Failed to update profile: '.$stmt->error]);
}

$stmt->close();
$conn->close();
?>
