<?php
header('Content-Type: application/json');
include 'config.php';

// Required fields
$product_id = $_POST['product_id'] ?? '';
$seller_id = $_POST['seller_id'] ?? '';
$name = $_POST['name'] ?? '';
$price = $_POST['price'] ?? '';
$product_type = $_POST['product_type'] ?? 'other';

// Optional fields with proper null handling
$weight_kg = !empty($_POST['weight_kg']) ? $_POST['weight_kg'] : NULL;
$promotion = !empty($_POST['promotion']) ? $_POST['promotion'] : NULL;
$description = !empty($_POST['description']) ? $_POST['description'] : NULL;
$contact_info = !empty($_POST['contact_info']) ? $_POST['contact_info'] : NULL;
$stock_quantity = !empty($_POST['stock_quantity']) ? (int)$_POST['stock_quantity'] : 0;
$category = !empty($_POST['category']) ? $_POST['category'] : NULL;
$unit = !empty($_POST['unit']) ? $_POST['unit'] : 'kg';
$harvest_date = !empty($_POST['harvest_date']) ? $_POST['harvest_date'] : NULL;
$is_available = isset($_POST['is_available']) ? (int)$_POST['is_available'] : 1;
$image_url = !empty($_POST['image_url']) ? $_POST['image_url'] : NULL; // Fixed NULL handling

if (empty($product_id) || empty($seller_id) || empty($name) || empty($price)) {
    echo json_encode(['status' => 'error', 'message' => 'Required fields missing']);
    exit;
}

// Prepare the update statement
$stmt = $conn->prepare(
    "UPDATE products SET 
        name=?, 
        product_type=?, 
        price=?, 
        weight_kg=?, 
        promotion=?, 
        description=?, 
        contact_info=?, 
        stock_quantity=?, 
        category=?, 
        unit=?, 
        harvest_date=?, 
        is_available=?, 
        image_url=?
    WHERE id=? AND seller_id=?"
);

if (!$stmt) {
    echo json_encode(['status' => 'error', 'message' => 'Prepare failed: '.$conn->error]);
    exit;
}

// Convert weight_kg to float or null
$weight_kg_value = ($weight_kg !== NULL) ? (float)$weight_kg : NULL;

// If image_url is empty string, set to NULL
if ($image_url === '') {
    $image_url = NULL;
}

// CORRECTED bind_param: 15 parameters total
$stmt->bind_param(
    "ssdssssissssiii",  // 15 characters for 15 parameters
    $name,              // s
    $product_type,      // s
    $price,             // s (decimal as string)
    $weight_kg_value,   // d (double/float) or NULL
    $promotion,         // s or NULL
    $description,       // s or NULL
    $contact_info,      // s or NULL
    $stock_quantity,    // i (integer)
    $category,          // s or NULL
    $unit,              // s
    $harvest_date,      // s or NULL
    $is_available,      // i (integer)
    $image_url,         // s or NULL
    $product_id,        // i (integer)
    $seller_id          // i (integer)
);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Product updated successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to update product: '.$stmt->error]);
}

$stmt->close();
$conn->close();
?>