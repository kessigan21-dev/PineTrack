<?php
header('Content-Type: application/json');
include 'config.php';

$stmt = $conn->prepare("
    SELECT 
        a.id, 
        a.title, 
        a.type, 
        a.details, 
        DATE(a.created_at) as date, 
        DATE(a.expiry_date) as expiry_date,
        e.name as seller_name,
        CASE 
            WHEN a.expiry_date IS NULL THEN 'active'
            WHEN a.expiry_date >= CURDATE() THEN 'active'
            ELSE 'expired'
        END as status
    FROM announcements a
    JOIN entrepreneurs e ON a.seller_id = e.id
    WHERE a.expiry_date IS NULL OR a.expiry_date >= CURDATE()
    ORDER BY a.created_at DESC
");

$stmt->execute();
$result = $stmt->get_result();

$announcements = [];
while($row = $result->fetch_assoc()){
    $announcements[] = $row;
}

echo json_encode(['status'=>'success', 'announcements'=>$announcements]);

$stmt->close();
$conn->close();
?>