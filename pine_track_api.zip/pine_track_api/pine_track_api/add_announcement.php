<?php
header('Content-Type: application/json');
include 'config.php';

$seller_id = $_POST['seller_id'] ?? '';
$title = $_POST['title'] ?? '';
$type = $_POST['type'] ?? 'General';
$details = $_POST['details'] ?? '';
$expiry_date = $_POST['expiry_date'] ?? null;

if(empty($seller_id) || empty($title) || empty($details)){
    echo json_encode(['status'=>'error', 'message'=>'Title and details are required']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO announcements (seller_id, title, type, details, expiry_date) VALUES (?, ?, ?, ?, ?)");
$expiry_date_param = !empty($expiry_date) ? $expiry_date : null;
$stmt->bind_param("issss", $seller_id, $title, $type, $details, $expiry_date_param);

if($stmt->execute()){
    echo json_encode(['status'=>'success', 'message'=>'Announcement added successfully']);
} else {
    echo json_encode(['status'=>'error', 'message'=>'Failed to add announcement: '.$stmt->error]);
}

$stmt->close();
$conn->close();
?>