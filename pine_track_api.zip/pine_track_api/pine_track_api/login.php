<?php
header('Content-Type: application/json');
include 'config.php';

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$role = $_POST['role'] ?? '';

if(empty($email) || empty($password) || empty($role)){
    echo json_encode(['success'=>false, 'message'=>'Fill all fields']);
    exit;
}

$table = $role === 'Entrepreneur' ? 'entrepreneurs' : 'customers';

$stmt = $conn->prepare("SELECT * FROM $table WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if($row = $result->fetch_assoc()){
    if(password_verify($password, $row['password'])){
        echo json_encode(['success'=>true, 'user'=>$row]);
    } else {
        echo json_encode(['success'=>false, 'message'=>'Wrong password']);
    }
} else {
    echo json_encode(['success'=>false, 'message'=>'User not found']);
}

$stmt->close();
$conn->close();
?>
