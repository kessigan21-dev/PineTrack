import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart';

class CustomerPurchaseScreen extends StatefulWidget {
  final Map<String, dynamic> product;
  final String customerId;

  const CustomerPurchaseScreen({
    Key? key,
    required this.product,
    required this.customerId,
  }) : super(key: key);

  @override
  State<CustomerPurchaseScreen> createState() => _CustomerPurchaseScreenState();
}

class _CustomerPurchaseScreenState extends State<CustomerPurchaseScreen> {
  final TextEditingController quantityController = TextEditingController(text: "1");
  String paymentMethod = 'cash';
  bool isLoading = false;

  // Your existing API endpoint
  final String purchaseApiUrl = "http://192.168.56.1/pine_track_api/customer_purchase.php";

  void makePurchase() async {
    String quantity = quantityController.text.trim();

    if (quantity.isEmpty || int.tryParse(quantity) == null) {
      Fluttertoast.showToast(msg: "Please enter a valid quantity");
      return;
    }

    int qty = int.parse(quantity);
    int stock = int.tryParse(widget.product['stock_quantity']?.toString() ?? '0') ?? 0;

    if (qty <= 0) {
      Fluttertoast.showToast(msg: "Quantity must be greater than 0");
      return;
    }

    if (qty > stock) {
      Fluttertoast.showToast(msg: "Only $stock units available");
      return;
    }

    setState(() => isLoading = true);

    try {
      var response = await http.post(
        Uri.parse(purchaseApiUrl),
        body: {
          'product_id': widget.product['id'].toString(),
          'seller_id': widget.product['seller_id'].toString(),
          'customer_id': widget.customerId,
          'quantity': quantity,
          'payment_method': paymentMethod,
        },
      );

      var data = json.decode(response.body);

      if (data['status'] == 'success') {
        Fluttertoast.showToast(
          msg: "Purchase successful! Total: RM ${data['total_price']}",
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );
        Navigator.pop(context, true);
      } else {
        Fluttertoast.showToast(
          msg: data['message'] ?? "Purchase failed",
          backgroundColor: Colors.red,
          textColor: Colors.white,
        );
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Network error: $e",
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  double calculateTotal() {
    int qty = int.tryParse(quantityController.text) ?? 0;
    double price = double.tryParse(widget.product['price']?.toString() ?? '0') ?? 0;
    return qty * price;
  }

  @override
  Widget build(BuildContext context) {
    double price = double.tryParse(widget.product['price']?.toString() ?? '0') ?? 0;
    String unit = widget.product['unit']?.toString() ?? 'unit';
    String sellerName = widget.product['seller_name']?.toString() ?? 'Unknown Seller';

    return Scaffold(
      appBar: AppBar(
        title: Text("Purchase ${widget.product['name']}"),
        backgroundColor: Colors.green.shade700,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Product Summary
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.product['name']?.toString() ?? 'Product',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text(
                      sellerName,
                      style: TextStyle(color: Colors.grey.shade600),
                    ),
                    SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Price",
                              style: TextStyle(color: Colors.grey.shade600),
                            ),
                            Text(
                              "RM ${price.toStringAsFixed(2)} / $unit",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.green.shade800,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              "Available Stock",
                              style: TextStyle(color: Colors.grey.shade600),
                            ),
                            Text(
                              widget.product['stock_quantity']?.toString() ?? '0',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue.shade700,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    if (widget.product['promotion'] != null && widget.product['promotion'].toString().isNotEmpty)
                      Container(
                        margin: EdgeInsets.only(top: 12),
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.orange.shade50,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.orange.shade200),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.local_offer, size: 16, color: Colors.orange.shade700),
                            SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                widget.product['promotion'].toString(),
                                style: TextStyle(color: Colors.orange.shade800),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 24),

            // Quantity Input
            Text(
              "Quantity",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 8),
            TextField(
              controller: quantityController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: "Enter quantity",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                prefixIcon: Icon(Icons.numbers, color: Colors.green.shade700),
                suffixIcon: IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () {
                    int current = int.tryParse(quantityController.text) ?? 0;
                    quantityController.text = (current + 1).toString();
                    setState(() {});
                  },
                ),
              ),
              onChanged: (value) => setState(() {}),
            ),

            SizedBox(height: 24),

            // Payment Method
            Text(
              "Payment Method",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(10),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: paymentMethod,
                  isExpanded: true,
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  items: [
                    DropdownMenuItem(
                      value: 'cash',
                      child: Row(
                        children: [
                          Icon(Icons.money, color: Colors.green),
                          SizedBox(width: 12),
                          Text("Cash on Delivery"),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'online',
                      child: Row(
                        children: [
                          Icon(Icons.payment, color: Colors.blue),
                          SizedBox(width: 12),
                          Text("Online Payment"),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'card',
                      child: Row(
                        children: [
                          Icon(Icons.credit_card, color: Colors.purple),
                          SizedBox(width: 12),
                          Text("Credit/Debit Card"),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'bank',
                      child: Row(
                        children: [
                          Icon(Icons.account_balance, color: Colors.orange),
                          SizedBox(width: 12),
                          Text("Bank Transfer"),
                        ],
                      ),
                    ),
                  ],
                  onChanged: (value) => setState(() => paymentMethod = value!),
                ),
              ),
            ),

            SizedBox(height: 32),

            // Order Summary
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Quantity", style: TextStyle(color: Colors.grey.shade600)),
                        Text("${quantityController.text} $unit"),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Unit Price", style: TextStyle(color: Colors.grey.shade600)),
                        Text("RM ${price.toStringAsFixed(2)}"),
                      ],
                    ),
                    Divider(height: 24, thickness: 1),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Total Amount",
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                        ),
                        Text(
                          "RM ${calculateTotal().toStringAsFixed(2)}",
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.green.shade800,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 32),

            // Purchase Button
            isLoading
                ? Center(child: CircularProgressIndicator())
                : SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: makePurchase,
                icon: Icon(Icons.shopping_cart_checkout, size: 24),
                label: Text(
                  "CONFIRM PURCHASE",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade700,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 2,
                ),
              ),
            ),

            SizedBox(height: 16),

            // Terms
            Text(
              "By completing this purchase, you agree to our terms and conditions. The seller will contact you for delivery arrangements.",
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade600,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}