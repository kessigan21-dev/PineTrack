import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class AddProductScreen extends StatefulWidget {
  final String sellerId;
  final Map<String, dynamic>? product;
  const AddProductScreen({Key? key, required this.sellerId, this.product})
      : super(key: key);

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final String addProductUrl =
      "http://192.168.56.1/pine_track_api/add_product.php";
  final String updateProductUrl =
      "http://192.168.56.1/pine_track_api/update_product.php";

  // Controllers
  final TextEditingController nameController = TextEditingController();
  final TextEditingController priceController = TextEditingController();
  final TextEditingController weightController = TextEditingController();
  final TextEditingController promoController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController contactController = TextEditingController();
  final TextEditingController stockController = TextEditingController();
  final TextEditingController categoryController = TextEditingController();
  final TextEditingController imageUrlController = TextEditingController();

  // Variables
  String productType = 'other';
  String unit = 'kg';
  DateTime? harvestDate;
  bool isAvailable = true;
  bool isLoading = false;
  bool isEditing = false;

  @override
  void initState() {
    super.initState();
    isEditing = widget.product != null;
    if (isEditing) {
      _loadProductData();
    }

    // Add listener to refresh UI when image URL changes
    imageUrlController.addListener(() {
      if (mounted) {
        setState(() {}); // This refreshes the preview when URL changes
      }
    });
  }

  void _loadProductData() {
    final product = widget.product!;
    nameController.text = product['name'] ?? '';
    priceController.text = product['price']?.toString() ?? '';
    productType = product['product_type'] ?? 'other';
    weightController.text = product['weight_kg']?.toString() ?? '';
    promoController.text = product['promotion'] ?? '';
    descriptionController.text = product['description'] ?? '';
    contactController.text = product['contact_info'] ?? '';
    stockController.text = product['stock_quantity']?.toString() ?? '0';
    categoryController.text = product['category'] ?? '';
    imageUrlController.text = product['image_url'] ?? '';
    unit = product['unit'] ?? 'kg';
    isAvailable = product['is_available'] == 1;

    if (product['harvest_date'] != null) {
      try {
        harvestDate = DateTime.parse(product['harvest_date']);
      } catch (e) {
        harvestDate = null;
      }
    }
  }

  void saveProduct() async {
    String name = nameController.text.trim();
    String price = priceController.text.trim();

    if (name.isEmpty || price.isEmpty) {
      Fluttertoast.showToast(msg: "Name and price are required");
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      // Handle image URL - if empty, send empty string (PHP will convert to NULL)
      String imageUrl = imageUrlController.text.trim();

      // Validate URL if provided
      if (imageUrl.isNotEmpty) {
        // Check if it looks like a valid URL
        if (!imageUrl.startsWith('http://') && !imageUrl.startsWith('https://')) {
          imageUrl = 'https://' + imageUrl;
        }

        // Simple URL validation
        try {
          Uri.parse(imageUrl);
        } catch (e) {
          Fluttertoast.showToast(msg: "Please enter a valid image URL");
          setState(() => isLoading = false);
          return;
        }
      }

      Map<String, String> body = {
        'seller_id': widget.sellerId,
        'name': name,
        'product_type': productType,
        'price': price,
        'weight_kg': weightController.text.trim(),
        'promotion': promoController.text.trim(),
        'description': descriptionController.text.trim(),
        'contact_info': contactController.text.trim(),
        'stock_quantity': stockController.text.trim().isEmpty
            ? '0'
            : stockController.text.trim(),
        'category': categoryController.text.trim(),
        'unit': unit,
        'harvest_date': harvestDate != null
            ? DateFormat('yyyy-MM-dd').format(harvestDate!)
            : '',
        'is_available': isAvailable ? '1' : '0',
        'image_url': imageUrl, // Use the processed imageUrl
      };

      if (isEditing) {
        body['product_id'] = widget.product!['id'].toString();
      }

      // Debug: Print what we're sending
      print('Sending data: $body');

      String url = isEditing ? updateProductUrl : addProductUrl;

      var response = await http.post(
        Uri.parse(url),
        body: body,
      ).timeout(Duration(seconds: 10));

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        Fluttertoast.showToast(msg: data['message']);

        if (data['status'] == 'success') {
          Navigator.pop(context, true);
        } else {
          Fluttertoast.showToast(msg: "Error: ${data['message']}");
        }
      } else {
        Fluttertoast.showToast(msg: "Server error: ${response.statusCode}");
      }
    } on TimeoutException catch (_) {
      Fluttertoast.showToast(msg: "Request timed out");
    } on SocketException catch (_) {
      Fluttertoast.showToast(msg: "No internet connection");
    } catch (e) {
      print('Error: $e');
      Fluttertoast.showToast(msg: "Error: $e");
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _selectHarvestDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: harvestDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != harvestDate) {
      setState(() {
        harvestDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? "Edit Product" : "Add Product"),
        backgroundColor: Color(0xFF4CAF50),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Product Type
            _buildSectionTitle("Product Type"),
            Wrap(
              spacing: 10,
              children: [
                ChoiceChip(
                  label: Text("🍍 Pineapple"),
                  selected: productType == 'pineapple',
                  onSelected: (selected) {
                    setState(() {
                      productType = selected ? 'pineapple' : 'other';
                      if (productType == 'pineapple') unit = 'kg';
                    });
                  },
                ),
                ChoiceChip(
                  label: Text("📦 Other Product"),
                  selected: productType == 'other',
                  onSelected: (selected) {
                    setState(() {
                      productType = selected ? 'other' : 'pineapple';
                    });
                  },
                ),
              ],
            ),

            SizedBox(height: 20),

            // Basic Information
            _buildSectionTitle("Basic Information"),
            _buildTextField(
              controller: nameController,
              label: "Product Name*",
              icon: Icons.shopping_bag,
            ),
            SizedBox(height: 12),
            _buildTextField(
              controller: descriptionController,
              label: "Description",
              icon: Icons.description,
              maxLines: 3,
            ),
            SizedBox(height: 12),
            _buildTextField(
              controller: categoryController,
              label: "Category (e.g., Fresh, Processed)",
              icon: Icons.category,
            ),

            SizedBox(height: 20),

            // Pricing & Stock
            _buildSectionTitle("Pricing & Stock"),
            Row(
              children: [
                Expanded(
                  child: _buildTextField(
                    controller: priceController,
                    label: "Price (RM)*",
                    icon: Icons.attach_money,
                    keyboardType: TextInputType.number,
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: _buildTextField(
                    controller: stockController,
                    label: "Stock Quantity",
                    icon: Icons.inventory,
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),

            SizedBox(height: 12),

            if (productType == 'pineapple')
              _buildTextField(
                controller: weightController,
                label: "Weight (kg)",
                icon: Icons.scale,
                keyboardType: TextInputType.number,
              ),

            SizedBox(height: 20),

            // Contact Information
            _buildSectionTitle("Contact Information"),
            _buildTextField(
              controller: contactController,
              label: "Contact Info for Customers",
              icon: Icons.phone,
              hint: "e.g., WhatsApp number or email",
            ),

            SizedBox(height: 20),

            // Promotion & Image
            _buildSectionTitle("Promotion & Media"),
            _buildTextField(
              controller: promoController,
              label: "Promotion/Offer",
              icon: Icons.local_offer,
            ),
            SizedBox(height: 12),

            // Existing image URL TextField
            _buildTextField(
              controller: imageUrlController,
              label: "Image URL (Optional)",
              icon: Icons.image,
              hint: "Paste image link here (http://...)",
            ),

            // ADD IMAGE PREVIEW HERE - RIGHT AFTER THE TEXTFIELD
            if (imageUrlController.text.trim().isNotEmpty)
              Padding(
                padding: EdgeInsets.only(top: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Image Preview:", style: TextStyle(fontWeight: FontWeight.w500)),
                    SizedBox(height: 8),
                    Container(
                      height: 150,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          imageUrlController.text.trim(),
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.broken_image, color: Colors.grey, size: 40),
                                  SizedBox(height: 8),
                                  Text("Invalid image URL", style: TextStyle(color: Colors.grey)),
                                ],
                              ),
                            );
                          },
                          loadingBuilder: (context, child, loadingProgress) {
                            if (loadingProgress == null) return child;
                            return Center(
                              child: CircularProgressIndicator(
                                value: loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded /
                                    loadingProgress.expectedTotalBytes!
                                    : null,
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            SizedBox(height: 20),

            // Additional Details
            _buildSectionTitle("Additional Details"),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Harvest Date",
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                        ),
                      ),
                      SizedBox(height: 8),
                      ElevatedButton.icon(
                        onPressed: _selectHarvestDate,
                        icon: Icon(Icons.calendar_today),
                        label: Text(
                          harvestDate != null
                              ? DateFormat('yyyy-MM-dd').format(harvestDate!)
                              : "Select Date",
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.grey[100],
                          foregroundColor: Colors.grey[800],
                          minimumSize: Size(double.infinity, 50),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Unit",
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                        ),
                      ),
                      SizedBox(height: 8),
                      DropdownButtonFormField<String>(
                        value: unit,
                        items: ['kg', 'piece', 'pack', 'box']
                            .map((unit) => DropdownMenuItem(
                          value: unit,
                          child: Text(unit.toUpperCase()),
                        ))
                            .toList(),
                        onChanged: (value) {
                          setState(() {
                            unit = value ?? 'kg';
                          });
                        },
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          contentPadding: EdgeInsets.symmetric(horizontal: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            SizedBox(height: 12),

            // Availability Switch
            SwitchListTile(
              title: Text("Product Available"),
              subtitle: Text("Turn off to mark as out of stock"),
              value: isAvailable,
              onChanged: (value) {
                setState(() {
                  isAvailable = value;
                });
              },
              secondary: Icon(
                isAvailable ? Icons.check_circle : Icons.cancel,
                color: isAvailable ? Colors.green : Colors.red,
              ),
            ),

            SizedBox(height: 30),

            // Save Button
            isLoading
                ? Center(child: CircularProgressIndicator())
                : ElevatedButton(
              onPressed: saveProduct,
              child: Text(isEditing ? "Update Product" : "Add Product"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF4CAF50),
                foregroundColor: Colors.white,
                minimumSize: Size(double.infinity, 50),
                textStyle: TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.grey[700],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hint,
    int maxLines = 1,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        prefixIcon: Icon(icon),
      ),
      maxLines: maxLines,
      keyboardType: keyboardType,
    );
  }
}