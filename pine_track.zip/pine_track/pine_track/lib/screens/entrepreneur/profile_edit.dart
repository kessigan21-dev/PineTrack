import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SellerProfileEdit extends StatefulWidget {
  final String id;
  final Map<String, dynamic> initialProfile;

  const SellerProfileEdit({
    Key? key,
    required this.id,
    required this.initialProfile,
  }) : super(key: key);

  @override
  State<SellerProfileEdit> createState() => _SellerProfileEditState();
}

class _SellerProfileEditState extends State<SellerProfileEdit> {
  late TextEditingController nameController;
  late TextEditingController emailController;
  late TextEditingController phoneController;
  late TextEditingController farmController;
  late TextEditingController shopController;
  late TextEditingController socialController;

  final String apiUrl = "http://192.168.56.1/pine_track_api/update_profile.php";
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.initialProfile['name'] ?? "");
    emailController = TextEditingController(text: widget.initialProfile['email'] ?? "");
    phoneController = TextEditingController(text: widget.initialProfile['phone'] ?? "");
    farmController = TextEditingController(text: widget.initialProfile['farm_location'] ?? "");
    shopController = TextEditingController(text: widget.initialProfile['shop_info'] ?? "");
    socialController = TextEditingController(text: widget.initialProfile['social_media'] ?? "");
  }

  void updateProfile() async {
    if (nameController.text.isEmpty || emailController.text.isEmpty) {
      Fluttertoast.showToast(msg: "Name and Email are required");
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      var response = await http.post(
        Uri.parse(apiUrl),
        body: {
          "id": widget.id,
          "name": nameController.text.trim(),
          "email": emailController.text.trim(),
          "phone": phoneController.text.trim(),
          "farm_location": farmController.text.trim(),
          "shop_info": shopController.text.trim(),
          "social_media": socialController.text.trim(),
        },
      );

      var data = json.decode(response.body);

      Fluttertoast.showToast(msg: data['message'] ?? "No response");

      if (data['status'] == 'success') {
        Navigator.pop(context);
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void _addSocialTemplate(String platform, String example) {
    final currentText = socialController.text;
    final newText = currentText.isEmpty ? example : '$currentText\n$example';
    socialController.text = newText;
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    farmController.dispose();
    shopController.dispose();
    socialController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Edit Profile"),
        backgroundColor: Colors.green.shade700,
        actions: [
          IconButton(
            icon: const Icon(Icons.help_outline),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text("Social Media Format"),
                  content: const Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Add social media links (one per line):"),
                      SizedBox(height: 8),
                      Text("• Facebook: fb.com/yourpage"),
                      Text("• Instagram: @yourusername"),
                      Text("• Website: https://yourwebsite.com"),
                      Text("• Or just paste any URL"),
                      SizedBox(height: 12),
                      Text("Example:"),
                      Text("fb.com/kluangpineapple\n@kluangpineapple"),
                    ],
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("Got it"),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile Picture Section (Placeholder)
            Center(
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.green.shade100,
                  borderRadius: BorderRadius.circular(50),
                  border: Border.all(color: Colors.green.shade300, width: 2),
                ),
                child: Icon(
                  Icons.person,
                  size: 50,
                  color: Colors.green.shade700,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Basic Information
            const Text(
              "Basic Information",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.green),
            ),
            const SizedBox(height: 16),

            _buildTextField(
              controller: nameController,
              label: "Full Name*",
              icon: Icons.person,
              hint: "Enter your full name",
            ),
            const SizedBox(height: 12),

            _buildTextField(
              controller: emailController,
              label: "Email Address*",
              icon: Icons.email,
              hint: "Enter your email",
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 12),

            _buildTextField(
              controller: phoneController,
              label: "Phone Number",
              icon: Icons.phone,
              hint: "+60 123 456 789",
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 20),

            // Business Information
            const Text(
              "Business Information",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.green),
            ),
            const SizedBox(height: 16),

            _buildTextField(
              controller: farmController,
              label: "Farm Location",
              icon: Icons.location_on,
              hint: "Kluang, Johor, Malaysia",
            ),
            const SizedBox(height: 12),

            _buildTextField(
              controller: shopController,
              label: "Shop Information",
              icon: Icons.store,
              hint: "Kluang Pineapple Market",
            ),
            const SizedBox(height: 20),

            // Social Media Section
            const Text(
              "Social Media Links",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.green),
            ),
            const SizedBox(height: 8),
            const Text(
              "Add one social link per line. The app will automatically detect the platform.",
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 12),

            // Quick Add Buttons
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _buildSocialChip(
                  label: "Facebook",
                  icon: Icons.facebook,
                  color: const Color(0xFF1877F2),
                  onTap: () => _addSocialTemplate("Facebook", "fb.com/yourpage"),
                ),
                _buildSocialChip(
                  label: "Instagram",
                  icon: Icons.camera_alt,
                  color: const Color(0xFFE4405F),
                  onTap: () => _addSocialTemplate("Instagram", "@yourusername"),
                ),
                _buildSocialChip(
                  label: "Website",
                  icon: Icons.public,
                  color: Colors.green.shade700,
                  onTap: () => _addSocialTemplate("Website", "https://yourwebsite.com"),
                ),
                _buildSocialChip(
                  label: "WhatsApp",
                  icon: Icons.chat,
                  color: const Color(0xFF25D366),
                  onTap: () => _addSocialTemplate("WhatsApp", "https://wa.me/60123456789"),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Social Media Text Field
            TextField(
              controller: socialController,
              maxLines: 5,
              decoration: InputDecoration(
                labelText: "Social Media Links",
                hintText: "Add one link per line:\nfb.com/yourpage\n@yourusername\nhttps://yourwebsite.com",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                filled: true,
                fillColor: Colors.grey.shade50,
                prefixIcon: const Icon(Icons.link),
              ),
            ),
            const SizedBox(height: 30),

            // Action Buttons
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : Column(
              children: [
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: updateProfile,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade700,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                    ),
                    child: const Text(
                      "Save Changes",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      side: BorderSide(color: Colors.grey.shade400),
                    ),
                    child: const Text(
                      "Cancel",
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hint,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        filled: true,
        fillColor: Colors.grey.shade50,
        prefixIcon: Icon(icon, color: Colors.green.shade700),
      ),
    );
  }

  Widget _buildSocialChip({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}