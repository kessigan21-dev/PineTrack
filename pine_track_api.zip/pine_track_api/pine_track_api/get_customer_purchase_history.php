<?php
header('Content-Type: application/json');
include 'config.php';

$customer_id = (int)($_GET['customer_id'] ?? 0);

if($customer_id === 0){
    echo json_encode(['status'=>'error', 'message'=>'Customer ID required']);
    exit;
}

$stmt = $conn->prepare("
    SELECT 
        st.id as transaction_id,
        p.name as product_name,
        p.category,
        e.name as seller_name,
        e.shop_info,
        st.quantity,
        st.unit_price,
        st.total_price,
        st.payment_method,
        DATE(st.transaction_date) as purchase_date,
        st.status,
        st.notes,
        p.image_url
    FROM sales_transactions st
    JOIN products p ON st.product_id = p.id
    JOIN entrepreneurs e ON st.seller_id = e.id
    WHERE st.customer_id = ?
    ORDER BY st.transaction_date DESC
");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$result = $stmt->get_result();

$purchases = [];
while($row = $result->fetch_assoc()){
    $purchases[] = $row;
}

echo json_encode(['status'=>'success', 'purchases'=>$purchases]);

$stmt->close();
$conn->close();
?>