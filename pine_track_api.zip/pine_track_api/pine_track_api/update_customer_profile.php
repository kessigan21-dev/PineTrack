<?php
header('Content-Type: application/json');
include 'config.php';

$id = $_POST['id'] ?? '';
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$address = $_POST['address'] ?? '';

if(empty($id) || empty($name) || empty($email)){
    echo json_encode(['status'=>'error', 'message'=>'Required fields missing']);
    exit;
}

$stmt = $conn->prepare("
    UPDATE customers 
    SET name=?, email=?, phone=?, address=?, updated_at=NOW() 
    WHERE id=?
");
$stmt->bind_param("ssssi", $name, $email, $phone, $address, $id);

if($stmt->execute()){
    echo json_encode(['status'=>'success', 'message'=>'Profile updated successfully']);
}else{
    echo json_encode(['status'=>'error', 'message'=>'Update failed']);
}

$stmt->close();
$conn->close();
?>