import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'login_screen.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);


  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  String selectedRole = "Entrepreneur";
  bool isLoading = false;

  final String signupUrl = "http://192.168.56.1/pine_track_api/signup.php";// Replace with your PHP API URL

  void signupUser() async {
    String name = nameController.text.trim();
    String email = emailController.text.trim();
    String password = passwordController.text.trim();

    if (name.isEmpty || email.isEmpty || password.isEmpty) {
      Fluttertoast.showToast(msg: "Please fill all fields");
      return;
    }

    // Set loading state
    setState(() {
      isLoading = true;
    });

    try {
      var response = await http.post(
        Uri.parse(signupUrl),
        body: {
          'name': nameController.text,
          'email': emailController.text,
          'password': passwordController.text,
          'role': selectedRole,
        },
      ).timeout(Duration(seconds: 10));

      var data = json.decode(response.body);

      Fluttertoast.showToast(msg: data['message']);
      if (data['status'] == "success") {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => LoginScreen()));
      }
    } catch (e) {
      if (e.toString().contains('timeout')) {
        Fluttertoast.showToast(msg: "Connection timeout. Check your server.");
      } else {
        Fluttertoast.showToast(msg: "Error: ${e.toString()}");
      }
      print("Signup error: $e");
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFFF8E7),
      appBar: AppBar(
        title: Text("Sign Up"),
        backgroundColor: Color(0xFF4CAF50),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Text('PineTrack Sign Up',
                  style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade700)),
              SizedBox(height: 30),
              TextField(controller: nameController, decoration: InputDecoration(labelText: "Name")),
              SizedBox(height: 20),
              TextField(controller: emailController, decoration: InputDecoration(labelText: "Email")),
              SizedBox(height: 20),
              TextField(controller: passwordController, decoration: InputDecoration(labelText: "Password"), obscureText: true),
              SizedBox(height: 20),
              DropdownButtonFormField<String>(
                decoration: InputDecoration(labelText: "Sign up as"),
                value: selectedRole,
                items: ["Entrepreneur", "Customer"]
                    .map((role) => DropdownMenuItem(
                  value: role,
                  child: Text(role),
                ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    selectedRole = value!;
                  });
                },
              ),
              SizedBox(height: 30),
              ElevatedButton(
                  onPressed: signupUser,
                  child: Text("Sign Up"),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade700,
                      padding:
                      EdgeInsets.symmetric(vertical: 16, horizontal: 30))),
            ],
          ),
        ),
      ),
    );
  }
}
