// constants/theme.dart - FULLY FIXED WITH WHITE ICONS
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ENHANCED COLOR PALETTE for better contrast
  static const Color primaryGreen = Color(0xFF2E7D32); // Deep emerald green
  static const Color secondaryGreen = Color(0xFF4CAF50); // Vibrant green
  static const Color accentYellow = Color(0xFFFFD54F); // Warm golden yellow
  static const Color lightYellow = Color(0xFFFFF8E1); // Soft cream yellow
  static const Color darkGreen = Color(0xFF1B5E20); // Dark forest green
  static const Color successColor = Color(0xFF388E3C); // Success green
  static const Color warningColor = Color(0xFFF57C00); // Orange for better visibility
  static const Color dangerColor = Color(0xFFD32F2F); // Deep red
  static const Color infoColor = Color(0xFF0288D1); // Sky blue

  // ENHANCED BACKGROUND for better text visibility
  static const Color backgroundColor = Color(0xFFFFF8E1); // Soft warm yellow
  static const Color surfaceColor = Color(0xFFFFFFFF); // Pure white
  static const Color cardColor = Color(0xFFFFFFFF); // White cards
  static const Color navBarColor = Color(0xFFFFFFFF); // White navbar

  // ENHANCED TEXT COLORS for better readability
  static const Color textPrimary = Color(0xFF212121); // Dark gray - better contrast
  static const Color textSecondary = Color(0xFF424242); // Medium dark gray
  static const Color textTertiary = Color(0xFF616161); // Medium gray
  static const Color textLight = Color(0xFF757575); // Light gray
  static const Color textOnDark = Color(0xFFFFFFFF); // White on dark backgrounds

  // NEW: Orange background for better visibility
  static const Color orangeBackground = Color(0xFFFFF3E0); // Light orange background
  static const Color orangeAccent = Color(0xFFFFB74D); // Medium orange

  // BORDER & DIVIDER - Lighter for better contrast
  static const Color borderColor = Color(0xFFE0E0E0); // Light gray
  static const Color dividerColor = Color(0xFFEEEEEE); // Very light gray

  // BACKGROUND GRADIENT
  static const LinearGradient backgroundGradient = LinearGradient(
    colors: [
      Color(0xFFFFFDE7), // Very light yellow
      Color(0xFFFFF9C4), // Light yellow
      Color(0xFFFFF8E1), // Cream
    ],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    stops: [0.0, 0.5, 1.0],
  );

  // MAIN PROFESSIONAL THEME - UPDATED WITH WHITE ICONS
  static ThemeData get professionalTheme {
    return ThemeData(
      // COLOR SCHEME - FIXED FOR WHITE ICONS
      primaryColor: primaryGreen,
      scaffoldBackgroundColor: backgroundColor,
      colorScheme: const ColorScheme.light(
        primary: primaryGreen,
        secondary: secondaryGreen,
        surface: surfaceColor,
        background: backgroundColor,
        onPrimary: Colors.white, // FIXED: White icons/text on green
        onSecondary: Color(0xFF212121), // Dark text on secondary
        onSurface: Color(0xFF212121), // Dark text on surfaces
        onBackground: Color(0xFF212121), // Dark text on background
        error: dangerColor,
      ),

      appBarTheme: AppBarTheme(
        backgroundColor: AppTheme.primaryGreen, // GREEN BACKGROUND
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.montserrat(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: Colors.white, // WHITE TEXT
          letterSpacing: -0.3,
        ),
        iconTheme: const IconThemeData(
          color: Colors.white, // WHITE BACK BUTTON
        ),
        actionsIconTheme: const IconThemeData(
          color: Colors.white, // WHITE ACTION ICONS
        ),
        toolbarHeight: 70,
      ),


      // Card Theme - Better shadows
      cardTheme: CardThemeData(
        color: cardColor,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        shadowColor: Colors.black.withOpacity(0.08),
        margin: const EdgeInsets.all(8),
      ),

      // ELEVATED BUTTON - GREEN WITH WHITE TEXT/ICONS
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white, // WHITE TEXT
          backgroundColor: primaryGreen,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 28),
          elevation: 0,
          shadowColor: Colors.transparent,
          textStyle: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
            fontSize: 16,
            letterSpacing: -0.2,
          ),
          minimumSize: const Size(88, 56),
        ),
      ),

      // OUTLINED BUTTON - GREEN OUTLINE WITH GREEN TEXT
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primaryGreen, // Green text
          side: const BorderSide(color: primaryGreen, width: 1.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 28),
          textStyle: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
            fontSize: 16,
            letterSpacing: -0.2,
          ),
        ),
      ),

      // TEXT BUTTON - GREEN TEXT
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primaryGreen,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          textStyle: GoogleFonts.inter(
            fontWeight: FontWeight.w500,
            fontSize: 15,
          ),
        ),
      ),

      // FLOATING ACTION BUTTON - GREEN WITH WHITE ICONS
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: primaryGreen,
        foregroundColor: Colors.white, // WHITE ICONS
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(18)),
        ),
        elevation: 4,
        highlightElevation: 8,
        sizeConstraints: BoxConstraints(minWidth: 68, minHeight: 68),
      ),

      // INPUT DECORATION THEME
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: borderColor, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: borderColor, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: primaryGreen, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: dangerColor, width: 1.5),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: dangerColor, width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        labelStyle: GoogleFonts.inter(
          color: textTertiary,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
        hintStyle: GoogleFonts.inter(
          color: textLight,
          fontSize: 14,
          fontWeight: FontWeight.normal,
        ),
        errorStyle: GoogleFonts.inter(
          color: dangerColor,
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),

      // ICON THEME - GREEN ICONS (for general use)
      iconTheme: const IconThemeData(
        color: primaryGreen,
        size: 24,
      ),

      // BOTTOM NAVIGATION BAR THEME
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: navBarColor,
        selectedItemColor: primaryGreen,
        unselectedItemColor: textTertiary,
        elevation: 8,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: GoogleFonts.inter(
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
        unselectedLabelStyle: GoogleFonts.inter(
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
        showSelectedLabels: true,
        showUnselectedLabels: true,
      ),

      // TAB BAR THEME
      tabBarTheme: TabBarThemeData(
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: primaryGreen,
        unselectedLabelColor: textTertiary,
        labelStyle: GoogleFonts.inter(
          fontWeight: FontWeight.w600,
          fontSize: 14,
        ),
        unselectedLabelStyle: GoogleFonts.inter(
          fontWeight: FontWeight.w500,
          fontSize: 14,
        ),
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: primaryGreen.withOpacity(0.1),
        ),
      ),

      // CHIP THEME - NO YELLOW BACKGROUND
      chipTheme: ChipThemeData(
        backgroundColor: const Color(0xFFFAFAFA), // Light gray
        selectedColor: primaryGreen.withOpacity(0.1),
        secondarySelectedColor: primaryGreen,
        disabledColor: textTertiary.withOpacity(0.12),
        labelStyle: GoogleFonts.inter(
          fontSize: 13,
          fontWeight: FontWeight.w500,
          color: textPrimary,
        ),
        secondaryLabelStyle: GoogleFonts.inter(
          fontSize: 13,
          color: Colors.white,
          fontWeight: FontWeight.w600,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),

      // TEXT THEME - BETTER CONTRAST
      textTheme: GoogleFonts.poppinsTextTheme().copyWith(
        displayLarge: GoogleFonts.poppins(
          fontSize: 48,
          fontWeight: FontWeight.w700,
          color: textPrimary,
          letterSpacing: -0.5,
        ),
        displayMedium: GoogleFonts.poppins(
          fontSize: 36,
          fontWeight: FontWeight.w600,
          color: textPrimary,
          letterSpacing: -0.25,
        ),
        displaySmall: GoogleFonts.poppins(
          fontSize: 28,
          fontWeight: FontWeight.w600,
          color: textPrimary,
        ),
        headlineMedium: GoogleFonts.poppins(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: textPrimary,
        ),
        headlineSmall: GoogleFonts.poppins(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: textPrimary,
        ),
        titleLarge: GoogleFonts.poppins(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: textPrimary,
        ),
        titleMedium: GoogleFonts.poppins(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: textPrimary,
        ),
        titleSmall: GoogleFonts.poppins(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: textPrimary,
        ),
        bodyLarge: GoogleFonts.poppins(
          fontSize: 16,
          fontWeight: FontWeight.normal,
          color: textSecondary,
        ),
        bodyMedium: GoogleFonts.poppins(
          fontSize: 14,
          fontWeight: FontWeight.normal,
          color: textSecondary,
        ),
        bodySmall: GoogleFonts.poppins(
          fontSize: 12,
          fontWeight: FontWeight.normal,
          color: textTertiary,
        ),
        labelLarge: GoogleFonts.poppins(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Colors.white, // White on buttons
        ),
      ),

      // DIALOG THEME
      dialogTheme: DialogThemeData(
        backgroundColor: surfaceColor,
        elevation: 12,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        titleTextStyle: GoogleFonts.montserrat(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: textPrimary,
          letterSpacing: -0.3,
        ),
        contentTextStyle: GoogleFonts.inter(
          fontSize: 15,
          color: textSecondary,
          height: 1.6,
        ),
      ),

      // SNACKBAR THEME
      snackBarTheme: SnackBarThemeData(
        backgroundColor: primaryGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        contentTextStyle: GoogleFonts.inter(
          color: Colors.white,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),

      // TOOLTIP THEME - WHITE TEXT
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: primaryGreen,
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 6,
              offset: Offset(0, 3),
            ),
          ],
        ),
        textStyle: TextStyle(
          color: Colors.white,
          fontSize: 13,
          fontWeight: FontWeight.w500,
          height: 1.2,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        margin: const EdgeInsets.symmetric(horizontal: 16),
        waitDuration: const Duration(milliseconds: 500),
        showDuration: const Duration(seconds: 2),
        preferBelow: false,
      ),


      // USE MATERIAL 3
      useMaterial3: true,
    );
  }
}

// Extension for easy access to colors
extension ThemeExtension on BuildContext {
  Color get orangeBackground => AppTheme.orangeBackground;
  Color get orangeAccent => AppTheme.orangeAccent;
  Color get primaryGreen => AppTheme.primaryGreen;

  // Helper method for white text on dark backgrounds
  TextStyle get whiteTextStyle => const TextStyle(color: Colors.white);
}